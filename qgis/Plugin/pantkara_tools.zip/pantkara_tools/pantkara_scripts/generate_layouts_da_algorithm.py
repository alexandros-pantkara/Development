# -*- coding: utf-8 -*-

"""
/***************************************************************************
 PantkaraTools
                                 A QGIS plugin
 Tools for Pantkara org
                              -------------------
        begin                : 2026-08-10
        copyright            : (C) 2026 by Alexandros Voukenas
        email                : alexandros@pkarapatsios.gr
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

QGIS equivalent of Parcel-analysis-and-layouts/create_layouts_da.py (ArcGIS).

The themed pages come from ThemeLayoutsAlgorithm; this adds the ΔΑΣΩΜΕΝΟΣ
ΑΓΡΟΣ extra: the four-frame ΔΙΑΧΡΟΝΙΚΗ ΠΑΡΟΥΣΙΑΣΗ page showing the parcel
over the orthophotos of different years.
"""

__author__ = 'Alexandros Voukenas'
__date__ = '2026-08-10'
__copyright__ = '(C) 2026 by Alexandros Voukenas'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

from qgis.core import QgsExpressionContextUtils, QgsProcessingException

from .theme_layouts_base import ThemeLayoutsAlgorithm

# The four-frame page (ArcGIS Layout_0). Frames are filled in reading order:
# top-left, top-right, bottom-left, bottom-right.
TEMPORAL_LAYOUT_NAME = "Διαχρονική Παρουσίαση Γεωτεμαχίου"


class GenerateLayoutsDA(ThemeLayoutsAlgorithm):
    """Build and export the ΔΑΣΩΜΕΝΟΣ ΑΓΡΟΣ layout set from map themes."""

    ALGORITHM_ID = "generatelayoutsda"
    DISPLAY_NAME = "Generate Layouts DA"
    TEMPLATE_FILE = "da_template_a4.qpt"
    TEMPORAL_TEMPLATE_FILE = "da_temporal_template_a4.qpt"

    TEMPORAL_THEMES = "TEMPORAL_THEMES"

    def purpose(self):
        return self.tr(
            "Builds and exports the report pages of a Δασωμένος Αγρός case "
            "from saved layout views, plus the four-frame temporal page."
        )

    def extra_help(self):
        return self.tr(
            "• Temporal page themes - one view per frame of the "
            "'{temporal}' page, in reading order: top-left, top-right, "
            "bottom-left, bottom-right. Each frame takes its view's bookmark "
            "extent, or the first page's extent when it has none. Frames "
            "left without a view follow the live map, for manual "
            "completion; the page is only exported when at least one view "
            "was given.\n"
        ).format(temporal=TEMPORAL_LAYOUT_NAME)

    def add_main_parameters(self, themes):
        self.addParameter(
            self.theme_parameter(
                self.TEMPORAL_THEMES,
                self.tr("Temporal page - one theme per frame, in reading order"),
                themes,
                optional=True,
            )
        )

    def after_pages(self, run):
        template_path = self.require_template(self.TEMPORAL_TEMPLATE_FILE)

        frame_themes = self.enum_strings(run.parameters, self.TEMPORAL_THEMES, run.context)
        for theme in frame_themes:
            run.check_theme(theme)

        fallback_extent = run.first_extent if run.first_extent is not None else run.shared_extent()
        feedback = run.feedback
        feedback.pushInfo("Creating layout: {}".format(TEMPORAL_LAYOUT_NAME))

        try:
            layout = self.load_page(run.project, template_path, TEMPORAL_LAYOUT_NAME, feedback)

            frames = self.map_items(layout)
            if not frames:
                raise QgsProcessingException("The temporal template has no map items.")
            if len(frame_themes) > len(frames):
                feedback.pushWarning(
                    "{} temporal themes given but the template has {} frame(s) - "
                    "the extra themes are ignored.".format(len(frame_themes), len(frames))
                )

            for index, frame in enumerate(frames):
                theme = frame_themes[index] if index < len(frame_themes) else None
                if theme:
                    frame.setFollowVisibilityPreset(True)
                    frame.setFollowVisibilityPresetName(theme)
                    extent = self.bookmark_extent(run.project, theme, run.map_crs) or fallback_extent
                    feedback.pushInfo("Frame {}: '{}'".format(index + 1, theme))
                else:
                    # Left following the live map so the operator can finish
                    # the page by hand, as in ArcGIS.
                    frame.setFollowVisibilityPreset(False)
                    extent = fallback_extent
                    feedback.pushInfo("Frame {}: no theme - left for manual completion".format(index + 1))
                if extent is not None:
                    frame.zoomToExtent(extent)

            # The template may carry the title itself; a blank label gets it.
            self.fill_title(layout, TEMPORAL_LAYOUT_NAME, feedback, required=False)
            QgsExpressionContextUtils.setLayoutVariable(layout, "layout_title", TEMPORAL_LAYOUT_NAME)
            layout.refresh()
            self.add_to_project(run.project, layout, feedback)

            if frame_themes:
                self.export_page(layout, run)
            else:
                feedback.pushInfo(
                    "'{}' created without themes - not exported.".format(TEMPORAL_LAYOUT_NAME)
                )
        except QgsProcessingException:
            raise
        except Exception as exc:  # noqa: BLE001 - the page must not sink the run
            feedback.pushWarning("Layout '{}' failed: {}".format(TEMPORAL_LAYOUT_NAME, exc))
