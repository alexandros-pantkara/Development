# -*- coding: utf-8 -*-

"""
/***************************************************************************
 PantkaraTools
                                 A QGIS plugin
 Tools for Pantkara org
                              -------------------
        begin                : 2026-10-01
        copyright            : (C) 2026 by Alexandros Voukenas
        email                : alexandros@pkarapatsios.gr
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

QGIS equivalent of the layer-creation cell of
other-tools/Antirrisi to polygon.ipynb (ArcGIS).

Creates the empty antirrisi polygon layer in the project's analysis
GeoPackage, styles it and adds it to the project, ready for Insert Antirrisi
Polygon to fill.
"""

__author__ = 'Alexandros Voukenas'
__date__ = '2026-10-01'
__copyright__ = '(C) 2026 by Alexandros Voukenas'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os

from qgis.PyQt.QtCore import QCoreApplication
from qgis.PyQt.QtGui import QColor, QFont
from qgis.core import (
    QgsCategorizedSymbolRenderer,
    QgsCoordinateReferenceSystem,
    QgsMapLayer,
    QgsPalLayerSettings,
    QgsProcessingAlgorithm,
    QgsProcessingException,
    QgsProcessingOutputString,
    QgsProcessingParameterString,
    QgsProject,
    QgsProviderRegistry,
    QgsTextFormat,
    QgsUnitTypes,
    QgsVectorFileWriter,
    QgsVectorLayer,
    QgsVectorLayerSimpleLabeling,
    QgsWkbTypes,
)

from .antirrisi_common import (
    ANALYSIS_GEOPACKAGE,
    ANALYSIS_SUBFOLDER,
    ANTIRRISI_FIELDS,
    CATEGORY_FIELD,
    GROUP_NAME,
    TARGET_CRS,
    analysis_geopackage,
    antirrisi_fields,
)
from .common import TEMPLATES_FOLDER, algorithm_flag

# The forest-map style; its categories are reused for the antirriseis, keyed
# on new_proteuon instead of KATHGORDX - what ApplySymbologyFromLayer did
# with 'VALUE_FIELD KATHGORDX new_proteuon'.
SYMBOLOGY_QML = "ΔΑΣΙΚΟΣ.qml"

LABEL_FONT = "Arial"
LABEL_SIZE_POINTS = 17
LABEL_COLOUR = (190, 20, 4)


class CreateAntirrisiLayer(QgsProcessingAlgorithm):
    """Create the empty antirriseis polygon layer."""

    LAYER_NAME = "LAYER_NAME"
    OUTPUT_LAYER = "OUTPUT_LAYER"

    def tr(self, string):
        return QCoreApplication.translate("CreateAntirrisiLayer", string)

    def createInstance(self):
        return CreateAntirrisiLayer()

    def name(self):
        return "createantirrisilayer"

    def displayName(self):
        return self.tr("Create Antirrisi Layer")

    def group(self):
        return self.tr(GROUP_NAME)

    def groupId(self):
        return GROUP_NAME

    def flags(self):
        # The layer is styled and added to the project, so the algorithm must
        # stay on the main thread and needs a project.
        return (
            super().flags()
            | algorithm_flag("NoThreading")
            | algorithm_flag("RequiresProject")
        )

    def shortHelpString(self):
        return self.tr(
            "Creates the empty layer that the αντιρρήσεις polygons are "
            "inserted into.\n\n"
            "HOW IT WORKS\n"
            "A polygon layer in {crs} is created inside the project's "
            "analysis GeoPackage - '{subfolder}/{gpkg}' beside the project "
            "file, made if it is not there yet - carrying the fields the "
            "αντίρρηση PDFs provide: {fields}. It is then added to the "
            "project, symbolised with the forest-map categories keyed on "
            "{category}, and labelled with the same field.\n\n"
            "INPUTS\n"
            "• Layer name - e.g. 'Antirrisi_Pappadaki'. One layer per case.\n\n"
            "NOTES\n"
            "• A layer of that name already in the GeoPackage is kept as it "
            "is and only restyled - polygons already inserted are never "
            "overwritten.\n"
            "• Fill it with Insert Antirrisi Polygon, once per αντίρρηση."
        ).format(
            crs=TARGET_CRS,
            subfolder=ANALYSIS_SUBFOLDER,
            gpkg=ANALYSIS_GEOPACKAGE,
            fields=", ".join(name for name, _type, _alias in ANTIRRISI_FIELDS),
            category=CATEGORY_FIELD,
        )

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterString(
                self.LAYER_NAME,
                self.tr("Layer name"),
            )
        )
        self.addOutput(
            QgsProcessingOutputString(self.OUTPUT_LAYER, self.tr("Layer source"))
        )

    # ------------------------------------------------------------------ #

    @staticmethod
    def geopackage_layer_names(gpkg_path):
        """Names of the layers already in the GeoPackage."""
        if not os.path.exists(gpkg_path):
            return []
        metadata = QgsProviderRegistry.instance().providerMetadata("ogr")
        return [sublayer.name() for sublayer in metadata.querySublayers(gpkg_path)]

    @staticmethod
    def layer_in_project(project, uri):
        """The project's own layer reading that GeoPackage layer, if any."""
        wanted = os.path.normcase(os.path.normpath(uri))
        for layer in project.mapLayers().values():
            if os.path.normcase(os.path.normpath(layer.source())) == wanted:
                return layer
        return None

    def create_layer(self, gpkg_path, layer_name, crs, context, feedback):
        """Write the empty layer into the GeoPackage."""
        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = "GPKG"
        options.layerName = layer_name
        options.fileEncoding = "UTF-8"
        # Overwriting the whole file would throw away the other cases' layers,
        # so only ever add a layer to an existing GeoPackage.
        options.actionOnExistingFile = (
            QgsVectorFileWriter.CreateOrOverwriteLayer
            if os.path.exists(gpkg_path)
            else QgsVectorFileWriter.CreateOrOverwriteFile
        )

        writer = QgsVectorFileWriter.create(
            gpkg_path,
            antirrisi_fields(),
            QgsWkbTypes.Polygon,
            crs,
            context.transformContext(),
            options,
        )
        try:
            if writer.hasError() != QgsVectorFileWriter.NoError:
                raise QgsProcessingException(
                    self.tr("Could not create the layer: {}").format(writer.errorMessage())
                )
        finally:
            # The file is only flushed when the writer is released.
            del writer

        feedback.pushInfo("Created layer '{}' in {}".format(layer_name, gpkg_path))

    def style_layer(self, layer, feedback):
        """Forest-map categories and labels, both keyed on new_proteuon."""
        qml_path = os.path.join(TEMPLATES_FOLDER, SYMBOLOGY_QML)
        if os.path.exists(qml_path):
            # Symbology only: the rest of that .qml describes the forest
            # layer's fields, which have nothing to do with this one.
            message, ok = layer.loadNamedStyle(qml_path, QgsMapLayer.Symbology)
            renderer = layer.renderer()
            if ok and isinstance(renderer, QgsCategorizedSymbolRenderer):
                renderer.setClassAttribute(CATEGORY_FIELD)
                feedback.pushInfo(
                    "Symbology from {} keyed on {}".format(SYMBOLOGY_QML, CATEGORY_FIELD)
                )
            elif ok:
                feedback.pushWarning(
                    "{} is not a categorised style - left as loaded.".format(SYMBOLOGY_QML)
                )
            else:
                feedback.pushWarning(
                    "Could not apply {}: {}".format(SYMBOLOGY_QML, message)
                )
        else:
            feedback.pushWarning("Symbology file not found: {}".format(qml_path))

        text_format = QgsTextFormat()
        text_format.setFont(QFont(LABEL_FONT))
        text_format.setSize(LABEL_SIZE_POINTS)
        text_format.setSizeUnit(QgsUnitTypes.RenderPoints)
        text_format.setColor(QColor(*LABEL_COLOUR))

        settings = QgsPalLayerSettings()
        settings.fieldName = CATEGORY_FIELD
        settings.setFormat(text_format)

        layer.setLabeling(QgsVectorLayerSimpleLabeling(settings))
        layer.setLabelsEnabled(True)

        for name, _field_type, alias in ANTIRRISI_FIELDS:
            index = layer.fields().indexOf(name)
            if index >= 0 and alias:
                layer.setFieldAlias(index, alias)

        layer.triggerRepaint()

    # ------------------------------------------------------------------ #

    def processAlgorithm(self, parameters, context, feedback):
        project = context.project() or QgsProject.instance()
        if project is None:
            raise QgsProcessingException(self.tr("This tool needs an open project."))

        gpkg_path = analysis_geopackage(project)
        if not gpkg_path:
            raise QgsProcessingException(
                self.tr("Save the project first - the analysis GeoPackage goes beside it.")
            )

        layer_name = self.parameterAsString(parameters, self.LAYER_NAME, context).strip()
        if not layer_name:
            raise QgsProcessingException(self.tr("Give the layer a name."))

        os.makedirs(os.path.dirname(gpkg_path), exist_ok=True)
        crs = QgsCoordinateReferenceSystem(TARGET_CRS)

        if layer_name in self.geopackage_layer_names(gpkg_path):
            feedback.pushInfo(
                "Layer '{}' already exists - keeping its contents, restyling.".format(layer_name)
            )
        else:
            self.create_layer(gpkg_path, layer_name, crs, context, feedback)

        uri = "{}|layername={}".format(gpkg_path, layer_name)

        # Restyle the copy that is already in the project instead of adding a
        # second one - re-running the tool must not litter the layer tree.
        layer = self.layer_in_project(project, uri)
        if layer is not None:
            feedback.pushInfo("'{}' is already in the project - restyling it.".format(layer_name))
        else:
            layer = QgsVectorLayer(uri, layer_name, "ogr")
            if not layer.isValid():
                raise QgsProcessingException(
                    self.tr("The layer could not be loaded back from {}").format(uri)
                )
            project.addMapLayer(layer)

        self.style_layer(layer, feedback)

        feedback.pushInfo(
            "Ready: {} feature(s) in '{}'. Add the antirriseis with Insert "
            "Antirrisi Polygon.".format(layer.featureCount(), layer_name)
        )
        return {self.OUTPUT_LAYER: uri}
