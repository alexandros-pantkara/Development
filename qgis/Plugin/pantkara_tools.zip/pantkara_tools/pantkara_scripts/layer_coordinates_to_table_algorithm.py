# -*- coding: utf-8 -*-

"""
/***************************************************************************
 PantkaraTools
                                 A QGIS plugin
 Tools for Pantkara org
                              -------------------
        begin                : 2026-08-10
        copyright            : (C) 2026 by Alexandros Voukenas
        email                : alexandros@pkarapatsios.gr
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

QGIS equivalent of Parcel-analysis-and-layouts/layer_coordinates_to_table.py
(ArcGIS).

Dumps every vertex of the input layer to a table of ORIG_FID / PART_NUM /
ΚΟΡΥΦΗ / X / Y, for use as the ΚΟΡΥΦΕΣ deliverable. The layer must be in
EPSG:2100 (GGRS87 / Greek Grid).
"""

__author__ = 'Alexandros Voukenas'
__date__ = '2026-08-10'
__copyright__ = '(C) 2026 by Alexandros Voukenas'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os

from qgis.PyQt.QtCore import QCoreApplication, QVariant
from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsFeatureRequest,
    QgsFeatureSink,
    QgsField,
    QgsFields,
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingException,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterFeatureSource,
    QgsWkbTypes,
)

REQUIRED_CRS = "EPSG:2100"

FID_FIELD = "ORIG_FID"
PART_FIELD = "PART_NUM"
VERTEX_FIELD = "ΚΟΡΥΦΗ"
X_FIELD = "X"
Y_FIELD = "Y"


class LayerCoordinatesToTable(QgsProcessingAlgorithm):
    """Write every vertex of a layer to a ΚΟΡΥΦΕΣ table."""

    INPUT = "INPUT"
    OUTPUT = "OUTPUT"

    def tr(self, string):
        return QCoreApplication.translate("LayerCoordinatesToTable", string)

    def createInstance(self):
        return LayerCoordinatesToTable()

    def name(self):
        return "layercoordinatestotable"

    def displayName(self):
        return self.tr("Layer Coordinates to Table")

    def group(self):
        return self.tr("Other")

    def groupId(self):
        return "Other"

    def shortHelpString(self):
        return self.tr(
            "Produces the ΚΟΡΥΦΕΣ table: the coordinates of every vertex of a "
            "layer.\n\n"
            "HOW IT WORKS\n"
            "One row per vertex, with ORIG_FID (the source feature), PART_NUM "
            "(0-based part), ΚΟΡΥΦΗ (1-based vertex within the part) and the "
            "X / Y coordinates rounded to 3 decimals. The output table is "
            "named <layer>_KORYFES.\n\n"
            "INPUTS\n"
            "• Input layer - must be in {} (ΕΓΣΑ87). Coordinates are written "
            "exactly as stored, never reprojected, so any other CRS is "
            "refused.\n\n"
            "NOTES\n"
            "• The closing vertex of each ring is included, so a four-corner "
            "parcel gives five rows.\n"
            "• Interior rings continue the numbering of their part; points "
            "and multipoints are all part 0.\n"
            "• For several layers at once use 'Run as Batch Process'."
        ).format(REQUIRED_CRS)

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.INPUT,
                self.tr("Input layer"),
                [QgsProcessing.TypeVectorAnyGeometry],
            )
        )
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT,
                self.tr("ΚΟΡΥΦΕΣ"),
                QgsProcessing.TypeVector,
            )
        )

    def output_base_name(self, parameters, context):
        """Name of the input, for the '<name>_KORYFES' output layer name."""
        layer = self.parameterAsLayer(parameters, self.INPUT, context)
        if layer is not None:
            return layer.name()
        raw = self.parameterAsString(parameters, self.INPUT, context)
        if raw:
            return os.path.splitext(os.path.basename(raw.split("|")[0]))[0]
        return "Layer"

    def processAlgorithm(self, parameters, context, feedback):
        source = self.parameterAsSource(parameters, self.INPUT, context)
        if source is None:
            raise QgsProcessingException(self.invalidSourceError(parameters, self.INPUT))

        source_crs = source.sourceCrs()
        if source_crs.authid() != REQUIRED_CRS:
            raise QgsProcessingException(
                self.tr(
                    "Error: the layer is in {} ({}). Layer must be in {}."
                ).format(
                    source_crs.description() or self.tr("an unknown CRS"),
                    source_crs.authid() or self.tr("no EPSG code"),
                    REQUIRED_CRS,
                )
            )

        fields = QgsFields()
        fields.append(QgsField(FID_FIELD, QVariant.LongLong))
        fields.append(QgsField(PART_FIELD, QVariant.Int))
        fields.append(QgsField(VERTEX_FIELD, QVariant.Int))
        fields.append(QgsField(X_FIELD, QVariant.Double, "double", 20, 3))
        fields.append(QgsField(Y_FIELD, QVariant.Double, "double", 20, 3))

        sink, sink_id = self.parameterAsSink(
            parameters, self.OUTPUT, context,
            fields, QgsWkbTypes.NoGeometry, QgsCoordinateReferenceSystem(),
        )
        if sink is None:
            raise QgsProcessingException(self.invalidSinkError(parameters, self.OUTPUT))

        total = source.featureCount()
        step = 100.0 / total if total else 0
        written = 0
        skipped = 0

        request = QgsFeatureRequest().setNoAttributes()
        for position, feature in enumerate(source.getFeatures(request)):
            if feedback.isCanceled():
                return {}
            feedback.setProgress(int(position * step))

            geom = feature.geometry()
            if geom.isNull() or geom.isEmpty():
                skipped += 1
                continue

            # Points and multipoints are reported as a single part numbered
            # through, the way the ArcGIS tool handled them.
            flatten_parts = geom.type() == QgsWkbTypes.PointGeometry

            current_part = None
            vertex_number = 0
            for index in range(geom.constGet().nCoordinates()):
                ok, vertex_id = geom.vertexIdFromVertexNr(index)
                if not ok:
                    continue

                part = 0 if flatten_parts else vertex_id.part
                if part != current_part:
                    current_part = part
                    vertex_number = 0
                vertex_number += 1

                point = geom.vertexAt(index)
                row = QgsFeature(fields)
                row.setAttributes([
                    feature.id(),
                    part,
                    vertex_number,
                    round(point.x(), 3),
                    round(point.y(), 3),
                ])
                sink.addFeature(row, QgsFeatureSink.FastInsert)
                written += 1

        if skipped:
            feedback.pushWarning(
                "{} feature(s) had no geometry and were skipped.".format(skipped)
            )

        table_name = "{}_KORYFES".format(self.output_base_name(parameters, context))
        if sink_id in context.layersToLoadOnCompletion():
            context.layerToLoadOnCompletionDetails(sink_id).name = table_name

        feedback.setProgress(100)
        feedback.pushInfo("Created table: {} ({} vertices)".format(table_name, written))

        return {self.OUTPUT: sink_id}
