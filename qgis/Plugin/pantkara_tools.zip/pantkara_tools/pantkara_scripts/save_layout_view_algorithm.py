# -*- coding: utf-8 -*-

"""
/***************************************************************************
 PantkaraTools
                                 A QGIS plugin
 Tools for Pantkara org
                              -------------------
        begin                : 2026-09-14
        copyright            : (C) 2026 by Alexandros Voukenas
        email                : alexandros@pkarapatsios.gr
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

Saves the current map state as a "layout view": a map theme (which layers are
visible, with which styles) and a project spatial bookmark (the extent), both
under the same name. The layout tools look the two up by that shared name.
"""

__author__ = 'Alexandros Voukenas'
__date__ = '2026-09-14'
__copyright__ = '(C) 2026 by Alexandros Voukenas'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (
    QgsBookmark,
    QgsLayerTreeModel,
    QgsMapThemeCollection,
    QgsProcessingAlgorithm,
    QgsProcessingException,
    QgsProcessingOutputString,
    QgsProcessingParameterDefinition,
    QgsProcessingParameterExtent,
    QgsProcessingParameterString,
    QgsProject,
    QgsReferencedRectangle,
)

from .common import algorithm_flag

# Bookmarks made by this tool are filed under this group in the bookmark
# panel, so they stand apart from the operator's own bookmarks.
DEFAULT_BOOKMARK_GROUP = "Layouts"


class SaveLayoutView(QgsProcessingAlgorithm):
    """Snapshot the current layers and extent under one name."""

    NAME = "NAME"
    EXTENT = "EXTENT"
    BOOKMARK_GROUP = "BOOKMARK_GROUP"
    VIEW_NAME = "VIEW_NAME"

    def tr(self, string):
        return QCoreApplication.translate("SaveLayoutView", string)

    def createInstance(self):
        return SaveLayoutView()

    def name(self):
        return "savelayoutview"

    def displayName(self):
        return self.tr("Save Layout View")

    def group(self):
        return self.tr("Layouts")

    def groupId(self):
        return "Layouts"

    def flags(self):
        # Reads the live layer tree and writes themes and bookmarks into the
        # project, so it must run on the main thread with a project open.
        return (
            super().flags()
            | algorithm_flag("NoThreading")
            | algorithm_flag("RequiresProject")
        )

    def shortHelpString(self):
        return self.tr(
            "Saves the current map as a layout view - the definition of one "
            "page for the Generate Layouts tools.\n\n"
            "HOW IT WORKS\n"
            "Two things are stored in the project under the same name:\n"
            "• a map theme - which layers are visible and the style each one "
            "uses (including any legend classes you have unticked);\n"
            "• a spatial bookmark - the extent.\n\n"
            "WORKFLOW\n"
            "Arrange the layers in the Layers panel, zoom the canvas to the "
            "view you want, run the tool, repeat for every page. Then run "
            "Generate Layouts DA / PROD and pick the views.\n\n"
            "INPUTS\n"
            "• View name - use the page's full title, e.g. 'Εικόνα 1: "
            "Γεωτεμάχιο & Επίδικο Τμήμα'. It becomes the layout name, the "
            "caption on the page and the PNG file name.\n"
            "• Extent - choose 'Use Current Map Canvas Extent'.\n\n"
            "NOTES\n"
            "• Saving an existing name updates the view instead of adding a "
            "duplicate.\n"
            "• Bookmarks are filed under the 'Layouts' group of the Spatial "
            "Bookmarks panel."
        )

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterString(
                self.NAME,
                self.tr("View name (theme and bookmark)"),
            )
        )
        self.addParameter(
            QgsProcessingParameterExtent(
                self.EXTENT,
                self.tr("Extent"),
            )
        )

        bookmark_group = QgsProcessingParameterString(
            self.BOOKMARK_GROUP,
            self.tr("Bookmark group"),
            defaultValue=DEFAULT_BOOKMARK_GROUP,
            optional=True,
        )
        bookmark_group.setFlags(
            bookmark_group.flags() | QgsProcessingParameterDefinition.FlagAdvanced
        )
        self.addParameter(bookmark_group)

        self.addOutput(QgsProcessingOutputString(self.VIEW_NAME, self.tr("View name")))

    # ------------------------------------------------------------------ #

    @staticmethod
    def layer_tree_model(project):
        """The Layers panel's model when running inside QGIS, else a fresh one.

        The panel's model knows which legend classes the operator has
        unchecked; a model built here would report every class as shown.
        """
        try:
            from qgis.utils import iface
        except ImportError:  # pragma: no cover - not inside QGIS desktop
            iface = None
        if iface is not None:
            try:
                view = iface.layerTreeView()
                if view is not None and view.layerTreeModel() is not None:
                    return view.layerTreeModel(), False
            except Exception:  # noqa: BLE001 - fall through to a private model
                pass
        return QgsLayerTreeModel(project.layerTreeRoot()), True

    @staticmethod
    def save_theme(project, name, feedback):
        collection = project.mapThemeCollection()
        model, is_private = SaveLayoutView.layer_tree_model(project)
        record = QgsMapThemeCollection.createThemeFromCurrentState(
            project.layerTreeRoot(), model
        )
        if collection.hasMapTheme(name):
            collection.update(name, record)
            feedback.pushInfo("Theme updated: {}".format(name))
        else:
            collection.insert(name, record)
            feedback.pushInfo("Theme created: {}".format(name))
        if is_private:
            feedback.pushInfo(
                "Layer tree read outside the QGIS window - unchecked legend "
                "classes are not captured."
            )
        return len(record.layerRecords())

    @staticmethod
    def save_bookmark(project, name, extent, group, feedback):
        manager = project.bookmarkManager()
        wanted = name.strip().casefold()
        existing = [b for b in manager.bookmarks() if b.name().strip().casefold() == wanted]

        if existing:
            bookmark = existing[0]
            bookmark.setExtent(extent)
            bookmark.setGroup(group)
            if not manager.updateBookmark(bookmark):
                raise QgsProcessingException(
                    "Could not update the bookmark '{}'.".format(name)
                )
            feedback.pushInfo("Bookmark updated: {}".format(name))
            for duplicate in existing[1:]:
                manager.removeBookmark(duplicate.id())
                feedback.pushInfo("Removed duplicate bookmark: {}".format(duplicate.name()))
        else:
            bookmark = QgsBookmark()
            bookmark.setName(name)
            bookmark.setExtent(extent)
            bookmark.setGroup(group)
            if not manager.addBookmark(bookmark):
                raise QgsProcessingException(
                    "Could not add the bookmark '{}'.".format(name)
                )
            feedback.pushInfo("Bookmark created: {}".format(name))

    # ------------------------------------------------------------------ #

    def processAlgorithm(self, parameters, context, feedback):
        project = context.project() or QgsProject.instance()
        if project is None:
            raise QgsProcessingException(self.tr("This tool needs an open project."))

        name = self.parameterAsString(parameters, self.NAME, context).strip()
        if not name:
            raise QgsProcessingException(self.tr("Give the view a name."))

        rect = self.parameterAsExtent(parameters, self.EXTENT, context)
        crs = self.parameterAsExtentCrs(parameters, self.EXTENT, context)
        if rect.isNull() or rect.isEmpty():
            raise QgsProcessingException(self.tr("The extent is empty."))
        if not crs.isValid():
            crs = project.crs()
        extent = QgsReferencedRectangle(rect, crs)

        group = self.parameterAsString(parameters, self.BOOKMARK_GROUP, context).strip()

        layer_count = self.save_theme(project, name, feedback)
        self.save_bookmark(project, name, extent, group, feedback)

        feedback.pushInfo(
            "View '{}' saved: {} layer(s) in the theme, extent {} ({}).".format(
                name, layer_count, rect.toString(2), crs.authid()
            )
        )
        return {self.VIEW_NAME: name}
