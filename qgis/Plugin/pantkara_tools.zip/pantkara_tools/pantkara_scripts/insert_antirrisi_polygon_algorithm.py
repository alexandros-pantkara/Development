# -*- coding: utf-8 -*-

"""
/***************************************************************************
 PantkaraTools
                                 A QGIS plugin
 Tools for Pantkara org
                              -------------------
        begin                : 2026-10-01
        copyright            : (C) 2026 by Alexandros Voukenas
        email                : alexandros@pkarapatsios.gr
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

QGIS equivalent of the insert cell of
other-tools/Antirrisi to polygon.ipynb (ArcGIS).

Reads the vertex list of one antirrisi, as copied out of the PDF, and adds it
to the layer made by Create Antirrisi Layer.
"""

__author__ = 'Alexandros Voukenas'
__date__ = '2026-10-01'
__copyright__ = '(C) 2026 by Alexandros Voukenas'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (
    QgsFeature,
    QgsGeometry,
    QgsPointXY,
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingException,
    QgsProcessingOutputNumber,
    QgsProcessingParameterNumber,
    QgsProcessingParameterString,
    QgsProcessingParameterVectorLayer,
    QgsVectorDataProvider,
)

from .antirrisi_common import GROUP_NAME, parse_vertices
from .common import algorithm_flag

# Two vertices closer than this (in metres) are the same point, so a block
# that already repeats its first vertex is not given a zero-length segment.
VERTEX_TOLERANCE = 1e-6

# How far the stated area may differ from the drawn one before it is worth a
# warning - a mistyped digit shows up well above this.
AREA_TOLERANCE = 0.01


class InsertAntirrisiPolygon(QgsProcessingAlgorithm):
    """Insert one antirrisi polygon from its PDF vertex list."""

    LAYER = "LAYER"
    SYNTETAGMENES = "SYNTETAGMENES"
    AA_OLD = "AA_OLD"
    AA_NEW = "AA_NEW"
    EMVADON = "EMVADON"
    NEW_PROTEUON = "NEW_PROTEUON"
    NEW_DEUTEREUON = "NEW_DEUTEREUON"
    NEW_TRITEUON = "NEW_TRITEUON"
    NEW_LANDTYPE = "NEW_LANDTYPE"
    VERTEX_COUNT = "VERTEX_COUNT"
    DRAWN_AREA = "DRAWN_AREA"

    # Parameter -> field, in the order the dialog shows them.
    ATTRIBUTE_MAP = (
        (AA_OLD, "aa_old"),
        (AA_NEW, "aa_new"),
        (EMVADON, "emvadon"),
        (NEW_PROTEUON, "new_proteuon"),
        (NEW_DEUTEREUON, "new_deutereuon"),
        (NEW_TRITEUON, "new_triteuon"),
        (NEW_LANDTYPE, "new_landtype"),
    )

    def tr(self, string):
        return QCoreApplication.translate("InsertAntirrisiPolygon", string)

    def createInstance(self):
        return InsertAntirrisiPolygon()

    def name(self):
        return "insertantirrisipolygon"

    def displayName(self):
        return self.tr("Insert Antirrisi Polygon")

    def group(self):
        return self.tr(GROUP_NAME)

    def groupId(self):
        return GROUP_NAME

    def flags(self):
        # Writes into a layer that is open in the project.
        return super().flags() | algorithm_flag("NoThreading")

    def shortHelpString(self):
        return self.tr(
            "Adds one αντίρρηση to the layer, from the vertex list in its "
            "PDF.\n\n"
            "HOW IT WORKS\n"
            "The coordinates are read straight out of the pasted text - every "
            "'X1=631342,970 Y1=4106531,850' pair, in the order listed - and "
            "become one polygon, closed automatically when the list does not "
            "already repeat its first vertex. The values typed beside it are "
            "written to the matching fields.\n\n"
            "INPUTS\n"
            "• Antirriseis layer - the layer from Create Antirrisi Layer.\n"
            "• Coordinates - paste the vertex block from the PDF. Comma or "
            "full stop both work as the decimal separator, and any extra text "
            "around the pairs is ignored.\n"
            "• Α.Α. αρχικό / Α.Α. νέο / Εμβαδόν and the new κατηγορίες - as "
            "stated in the decision. Leave Εμβαδόν at 0 to store the area of "
            "the drawn polygon instead.\n\n"
            "NOTES\n"
            "• The area of the drawn polygon is reported, and compared with "
            "the stated Εμβαδόν - a mismatch means a mistyped coordinate.\n"
            "• Run once per αντίρρηση; the layer keeps what is already in it."
        )

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.LAYER,
                self.tr("Antirriseis layer"),
                [QgsProcessing.TypeVectorPolygon],
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.SYNTETAGMENES,
                self.tr("Coordinates (pasted from the PDF)"),
                multiLine=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.AA_OLD,
                self.tr("Α.Α. αρχικό"),
                type=QgsProcessingParameterNumber.Integer,
                optional=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.AA_NEW,
                self.tr("Α.Α. νέο"),
                type=QgsProcessingParameterNumber.Integer,
                optional=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.EMVADON,
                self.tr("Εμβαδόν (0: use the drawn area)"),
                type=QgsProcessingParameterNumber.Double,
                defaultValue=0.0,
                minValue=0.0,
                optional=True,
            )
        )
        for parameter_name, label in (
            (self.NEW_PROTEUON, self.tr("Νέος Πρωτεύων")),
            (self.NEW_DEUTEREUON, self.tr("Νέος Δευτερεύων")),
            (self.NEW_TRITEUON, self.tr("Νέος Τριτεύων")),
            (self.NEW_LANDTYPE, self.tr("Νέο Landtype")),
        ):
            self.addParameter(
                QgsProcessingParameterString(
                    parameter_name, label, defaultValue="", optional=True
                )
            )

        self.addOutput(
            QgsProcessingOutputNumber(self.VERTEX_COUNT, self.tr("Vertices read"))
        )
        self.addOutput(
            QgsProcessingOutputNumber(self.DRAWN_AREA, self.tr("Drawn area"))
        )

    # ------------------------------------------------------------------ #

    @staticmethod
    def build_polygon(points):
        """A closed polygon from the listed vertices."""
        ring = [QgsPointXY(x, y) for x, y in points]
        if ring[0].compare(ring[-1], VERTEX_TOLERANCE):
            ring[-1] = QgsPointXY(ring[0])
        else:
            ring.append(QgsPointXY(ring[0]))
        return QgsGeometry.fromPolygonXY([ring])

    def collect_attributes(self, parameters, context, layer, feedback):
        """Field index -> value, for the fields this layer actually has."""
        values = {
            self.AA_OLD: self.parameterAsInt(parameters, self.AA_OLD, context)
            if parameters.get(self.AA_OLD) is not None else None,
            self.AA_NEW: self.parameterAsInt(parameters, self.AA_NEW, context)
            if parameters.get(self.AA_NEW) is not None else None,
            self.EMVADON: self.parameterAsDouble(parameters, self.EMVADON, context),
            self.NEW_PROTEUON: self.parameterAsString(parameters, self.NEW_PROTEUON, context),
            self.NEW_DEUTEREUON: self.parameterAsString(parameters, self.NEW_DEUTEREUON, context),
            self.NEW_TRITEUON: self.parameterAsString(parameters, self.NEW_TRITEUON, context),
            self.NEW_LANDTYPE: self.parameterAsString(parameters, self.NEW_LANDTYPE, context),
        }

        attributes = {}
        missing = []
        for parameter_name, field_name in self.ATTRIBUTE_MAP:
            index = layer.fields().indexOf(field_name)
            if index < 0:
                missing.append(field_name)
                continue
            attributes[index] = values[parameter_name]
        if missing:
            feedback.pushWarning(
                "The layer has no field(s) {} - those values are not "
                "stored.".format(", ".join(missing))
            )
        return attributes

    # ------------------------------------------------------------------ #

    def processAlgorithm(self, parameters, context, feedback):
        layer = self.parameterAsVectorLayer(parameters, self.LAYER, context)
        if layer is None:
            raise QgsProcessingException(self.invalidSourceError(parameters, self.LAYER))

        provider = layer.dataProvider()
        if not provider.capabilities() & QgsVectorDataProvider.AddFeatures:
            raise QgsProcessingException(
                self.tr("'{}' does not accept new features.").format(layer.name())
            )

        text = self.parameterAsString(parameters, self.SYNTETAGMENES, context)
        points = parse_vertices(text)
        if len(points) < 3:
            raise QgsProcessingException(
                self.tr(
                    "Only {} vertex/vertices could be read. Expected lines like "
                    "'X1=631342,970 Y1=4106531,850'."
                ).format(len(points))
            )
        feedback.pushInfo("{} vertices read.".format(len(points)))

        geometry = self.build_polygon(points)
        if geometry.isNull() or geometry.isEmpty():
            raise QgsProcessingException(self.tr("The vertices do not form a polygon."))
        if not geometry.isGeosValid():
            feedback.pushWarning(
                "The polygon is self-intersecting - check the vertex order in the PDF."
            )

        drawn_area = round(geometry.area(), 2)
        feedback.pushInfo("Drawn area: {} m2".format(drawn_area))

        attributes = self.collect_attributes(parameters, context, layer, feedback)

        emvadon_index = layer.fields().indexOf("emvadon")
        if emvadon_index in attributes:
            stated = attributes[emvadon_index]
            if not stated:
                attributes[emvadon_index] = drawn_area
                feedback.pushInfo("No Εμβαδόν given - storing the drawn area.")
            elif abs(stated - drawn_area) > max(stated, drawn_area) * AREA_TOLERANCE:
                feedback.pushWarning(
                    "The stated Εμβαδόν ({}) and the drawn area ({}) differ by "
                    "more than {:.0f}% - check the coordinates.".format(
                        stated, drawn_area, AREA_TOLERANCE * 100
                    )
                )

        feature = QgsFeature(layer.fields())
        feature.setGeometry(geometry)
        for index, value in attributes.items():
            feature.setAttribute(index, value)

        ok, _added = provider.addFeatures([feature])
        if not ok:
            raise QgsProcessingException(
                self.tr("Could not add the polygon: {}").format(provider.lastError())
            )

        layer.updateExtents()
        layer.reload()
        layer.triggerRepaint()

        feedback.pushInfo(
            "Inserted into '{}' - {} feature(s) now.".format(layer.name(), layer.featureCount())
        )
        return {self.VERTEX_COUNT: len(points), self.DRAWN_AREA: drawn_area}
