# -*- coding: utf-8 -*-

"""
/***************************************************************************
 PantkaraTools
                                 A QGIS plugin
 Tools for Pantkara org
                              -------------------
        begin                : 2026-08-10
        copyright            : (C) 2026 by Alexandros Voukenas
        email                : alexandros@pkarapatsios.gr
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

QGIS equivalent of Parcel-analysis-and-layouts/convert_from_cad.py (ArcGIS).

Reads a DXF drawing, turns its closed outlines into polygons, assigns the
working coordinate system and writes a clean layer carrying only Emvadon (and
an empty 'parcel' field when asked for), styled from ΓΕΩΤΕΜΑΧΙΟ.qml.
"""

__author__ = 'Alexandros Voukenas'
__date__ = '2026-08-10'
__copyright__ = '(C) 2026 by Alexandros Voukenas'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

from qgis.PyQt.QtCore import QCoreApplication, QVariant
from qgis.core import (
    Qgis,
    QgsFeature,
    QgsFeatureSink,
    QgsField,
    QgsFields,
    QgsGeometry,
    QgsPointXY,
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingException,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterCrs,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterFile,
    QgsProviderRegistry,
    QgsVectorLayer,
    QgsWkbTypes,
)

from .common import algorithm_flag, register_style_post_processor

AREA_FIELD = "Emvadon"
PARCEL_FIELD = "parcel"

# Two vertices closer than this (in drawing units) are treated as the same
# point, so a ring that is already closed is not given a zero-length segment.
VERTEX_TOLERANCE = 1e-9


class ConvertFromCAD(QgsProcessingAlgorithm):
    """Convert a DXF drawing into a clean polygon layer."""

    INPUT = "INPUT"
    TARGET_CRS = "TARGET_CRS"
    IS_PARCEL = "IS_PARCEL"
    OUTPUT = "OUTPUT"

    def tr(self, string):
        return QCoreApplication.translate("ConvertFromCAD", string)

    def createInstance(self):
        return ConvertFromCAD()

    def name(self):
        return "convertfromcad"

    def displayName(self):
        return self.tr("Convert from CAD")

    def group(self):
        return self.tr("Parcel Tools")

    def groupId(self):
        # Matches the id the sibling algorithms use, so they share one group
        # node in the toolbox.
        return "Parcel Tools"

    def flags(self):
        # The result is styled and added to the project, so it must stay on
        # the main thread.
        return (
            super().flags()
            | algorithm_flag("NoThreading")
            | algorithm_flag("RequiresProject")
        )

    def shortHelpString(self):
        return self.tr(
            "Turns a surveyor's DXF drawing into the parcel polygon layer.\n\n"
            "HOW IT WORKS\n"
            "Each closed outline in the drawing becomes one polygon (an open "
            "outline is closed by joining its last vertex to its first). If "
            "the drawing already contains filled polygons - hatches or "
            "solids - those are used instead and the outlines are ignored. "
            "The chosen coordinate system is assigned to the drawing's raw "
            "coordinates; nothing is reprojected.\n\n"
            "INPUTS\n"
            "• Input CAD dataset - a .dxf file.\n"
            "• Coordinate system to assign - EPSG:2100 by default.\n"
            "• This is a parcel layer - tick it for the ΓΕΩΤΕΜΑΧΙΟ: it adds "
            "the empty 'parcel' field by which the other tools recognise the "
            "parcel layer.\n\n"
            "OUTPUT\n"
            "A polygon layer with Emvadon (area in the chosen CRS, 3 "
            "decimals) and, when ticked, 'parcel'. Every CAD attribute is "
            "dropped. The layer is styled from ΓΕΩΤΕΜΑΧΙΟ.qml.\n\n"
            "NOTES\n"
            "• Outlines with fewer than three distinct vertices are skipped "
            "and counted in the log."
        )

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFile(
                self.INPUT,
                self.tr("Input CAD dataset"),
                behavior=QgsProcessingParameterFile.File,
                fileFilter=self.tr("DXF drawings (*.dxf *.DXF)"),
            )
        )
        self.addParameter(
            QgsProcessingParameterCrs(
                self.TARGET_CRS,
                self.tr("Coordinate system to assign"),
                defaultValue="EPSG:2100",
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.IS_PARCEL,
                self.tr("This is a parcel layer (adds an empty 'parcel' field)"),
                defaultValue=False,
            )
        )
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT,
                self.tr("Converted layer"),
                QgsProcessing.TypeVectorPolygon,
            )
        )

    # ------------------------------------------------------------------ #
    # geometry helpers
    # ------------------------------------------------------------------ #

    @staticmethod
    def rings_of(geom):
        """Vertex rings of a line geometry, with curves segmentised first."""
        work = QgsGeometry(geom)
        if QgsWkbTypes.isCurvedType(work.wkbType()):
            segmentised = work.constGet().segmentize()
            if segmentised is None:
                return []
            work = QgsGeometry(segmentised)
        if work.isMultipart():
            return work.asMultiPolyline()
        polyline = work.asPolyline()
        return [polyline] if polyline else []

    @classmethod
    def close_ring(cls, points):
        """Drop repeated vertices and close the ring; None when too short."""
        cleaned = []
        for point in points:
            if cleaned and cleaned[-1].compare(point, VERTEX_TOLERANCE):
                continue
            cleaned.append(QgsPointXY(point))

        if len(cleaned) > 1 and cleaned[0].compare(cleaned[-1], VERTEX_TOLERANCE):
            cleaned.pop()

        if len(cleaned) < 3:
            return None

        cleaned.append(QgsPointXY(cleaned[0]))
        return cleaned

    @classmethod
    def polygon_from_line(cls, geom):
        """One polygon per ring of a line geometry; None when nothing closes.

        This is the ArcGIS fallback path: each polyline becomes its own
        polygon rather than being noded against its neighbours.
        """
        polygons = []
        for ring in cls.rings_of(geom):
            closed = cls.close_ring(ring)
            if closed is None:
                continue
            polygon = QgsGeometry.fromPolygonXY([closed])
            if polygon.isNull() or polygon.isEmpty():
                continue
            polygons.append(polygon)

        if not polygons:
            return None

        result = polygons[0] if len(polygons) == 1 else QgsGeometry.collectGeometry(polygons)
        return cls.cleaned_polygon(result)

    @staticmethod
    def cleaned_polygon(geom):
        """A valid, non-degenerate polygon geometry, or None."""
        if geom is None or geom.isNull() or geom.isEmpty():
            return None
        if not geom.isGeosValid():
            geom = geom.makeValid()
            if geom is None or geom.isNull() or geom.isEmpty():
                return None
        parts = [part for part in geom.asGeometryCollection()
                 if part.type() == QgsWkbTypes.PolygonGeometry and not part.isEmpty()]
        if not parts:
            return None
        geom = parts[0] if len(parts) == 1 else QgsGeometry.collectGeometry(parts)
        if geom.isNull() or geom.area() <= 0:
            return None
        geom.convertToMultiType()
        return geom

    # ------------------------------------------------------------------ #
    # main
    # ------------------------------------------------------------------ #

    def read_sublayers(self, path, feedback):
        """Split the DXF's sublayers into polygon sources and line sources."""
        metadata = QgsProviderRegistry.instance().providerMetadata("ogr")
        sublayers = metadata.querySublayers(
            path, Qgis.SublayerQueryFlag.ResolveGeometryType
        )
        if not sublayers:
            raise QgsProcessingException(
                self.tr("No readable layers were found in {}.").format(path)
            )

        polygon_layers = []
        line_layers = []
        for sublayer in sublayers:
            layer = QgsVectorLayer(sublayer.uri(), sublayer.name(), "ogr")
            if not layer.isValid():
                feedback.pushWarning(
                    "Could not read sublayer '{}' - skipped.".format(sublayer.name())
                )
                continue
            if layer.geometryType() == QgsWkbTypes.PolygonGeometry:
                polygon_layers.append(layer)
            elif layer.geometryType() == QgsWkbTypes.LineGeometry:
                line_layers.append(layer)
            else:
                feedback.pushInfo(
                    "Ignoring '{}' ({} geometry).".format(
                        sublayer.name(), QgsWkbTypes.displayString(sublayer.wkbType())
                    )
                )

        return polygon_layers, line_layers

    def processAlgorithm(self, parameters, context, feedback):
        path = self.parameterAsFile(parameters, self.INPUT, context)
        if not path:
            raise QgsProcessingException(self.invalidSourceError(parameters, self.INPUT))

        target_crs = self.parameterAsCrs(parameters, self.TARGET_CRS, context)
        if not target_crs.isValid():
            raise QgsProcessingException(self.tr("The chosen coordinate system is not valid."))

        is_parcel = self.parameterAsBool(parameters, self.IS_PARCEL, context)

        fields = QgsFields()
        fields.append(QgsField(AREA_FIELD, QVariant.Double, "double", 20, 3))
        if is_parcel:
            fields.append(QgsField(PARCEL_FIELD, QVariant.String, "string", 50))

        sink, sink_id = self.parameterAsSink(
            parameters, self.OUTPUT, context,
            fields, QgsWkbTypes.MultiPolygon, target_crs,
        )
        if sink is None:
            raise QgsProcessingException(self.invalidSinkError(parameters, self.OUTPUT))

        feedback.pushInfo("Reading CAD dataset: {}".format(path))
        polygon_layers, line_layers = self.read_sublayers(path, feedback)

        for layer in polygon_layers + line_layers:
            source_crs = layer.crs()
            if source_crs.isValid() and source_crs != target_crs:
                feedback.pushWarning(
                    "The drawing declares {} - the chosen {} is assigned instead, "
                    "coordinates are not reprojected.".format(
                        source_crs.authid() or source_crs.description(), target_crs.authid()
                    )
                )
                break

        # ArcGIS used the CAD Polygon feature class when it had features and
        # only fell back to the polylines when it was empty.
        polygon_count = sum(layer.featureCount() for layer in polygon_layers)
        if polygon_count > 0:
            feedback.pushInfo(
                "Using the {} polygon(s) in the drawing.".format(polygon_count)
            )
            sources, from_lines = polygon_layers, False
        else:
            feedback.pushWarning(
                "The drawing contains no polygons - converting outlines to polygons..."
            )
            sources, from_lines = line_layers, True

        total = sum(layer.featureCount() for layer in sources)
        if total <= 0:
            raise QgsProcessingException(
                self.tr("The drawing contains no polygons and no outlines to close.")
            )

        converted = 0
        skipped = 0
        position = 0
        for layer in sources:
            for feature in layer.getFeatures():
                if feedback.isCanceled():
                    return {}
                position += 1
                feedback.setProgress(int(position * 100.0 / total))

                geom = feature.geometry()
                if geom.isNull() or geom.isEmpty():
                    skipped += 1
                    continue

                polygon = (self.polygon_from_line(geom) if from_lines
                           else self.cleaned_polygon(geom))
                if polygon is None:
                    skipped += 1
                    continue

                out_feature = QgsFeature(fields)
                out_feature.setGeometry(polygon)
                attributes = [round(polygon.area(), 3)]
                if is_parcel:
                    attributes.append("")
                out_feature.setAttributes(attributes)
                sink.addFeature(out_feature, QgsFeatureSink.FastInsert)
                converted += 1

        if from_lines:
            feedback.pushInfo(
                "Polyline to Polygon conversion complete: {} feature(s) converted, "
                "{} skipped.".format(converted, skipped)
            )
        else:
            feedback.pushInfo(
                "{} polygon(s) written, {} skipped.".format(converted, skipped)
            )

        if converted == 0:
            feedback.pushWarning(
                "Nothing could be converted - check that the drawing's outlines "
                "are closed and have at least three distinct vertices."
            )

        register_style_post_processor(context, sink_id, "ΓΕΩΤΕΜΑΧΙΟ.qml")

        feedback.pushInfo("CAD dataset converted successfully.")
        return {self.OUTPUT: sink_id}
