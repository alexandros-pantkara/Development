# -*- coding: utf-8 -*-

"""
/***************************************************************************
 PantkaraTools
                                 A QGIS plugin
 Tools for Pantkara org
                              -------------------
        begin                : 2026-08-10
        copyright            : (C) 2026 by Alexandros Voukenas
        email                : alexandros@pkarapatsios.gr
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

QGIS equivalent of Parcel-analysis-and-layouts/create_layouts_prod.py (ArcGIS).

The themed pages come from ThemeLayoutsAlgorithm; this adds the ΠΡΟΔΗΛΟ
ΣΦΑΛΜΑ extra: the closing 'Ενδεικτικές Φωτογραφίες' page - a small location
map beside space the operator fills with site photographs by hand.
"""

__author__ = 'Alexandros Voukenas'
__date__ = '2026-08-10'
__copyright__ = '(C) 2026 by Alexandros Voukenas'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

from qgis.core import (
    QgsExpressionContextUtils,
    QgsLayoutItemLabel,
    QgsProcessingException,
)

from .theme_layouts_base import ThemeLayoutsAlgorithm

# Where the template wants the page number. The label is rewritten to read it
# from the @image_number layout variable, so the number stays editable in the
# layout's Variables panel.
NUMBER_PLACEHOLDER = "[]"
NUMBER_EXPRESSION = "[% @image_number %]"


class GenerateLayoutsPROD(ThemeLayoutsAlgorithm):
    """Build and export the ΠΡΟΔΗΛΟ ΣΦΑΛΜΑ layout set from map themes."""

    ALGORITHM_ID = "generatelayoutsprod"
    DISPLAY_NAME = "Generate Layouts PROD"
    TEMPLATE_FILE = "da_template_a4.qpt"
    PHOTOS_TEMPLATE_FILE = "prod_anc_photos_a4.qpt"

    PHOTOS_THEME = "PHOTOS_THEME"

    def purpose(self):
        return self.tr(
            "Builds and exports the report pages of a Πρόδηλο Σφάλμα case "
            "from saved layout views, plus the closing photographs page."
        )

    def extra_help(self):
        return self.tr(
            "• Photos page theme - the view shown in the small map frame of "
            "the closing 'Ενδεικτικές Φωτογραφίες' page (at its bookmark, or "
            "the first page's extent). Left blank, the frame follows the live "
            "map. The page is numbered one past the highest 'Εικόνα N' among "
            "the selected views and is created in the project for the "
            "photographs to be added by hand - it is not exported. Its number "
            "can be changed later in the layout's Variables panel "
            "(@image_number).\n"
        )

    def add_main_parameters(self, themes):
        self.addParameter(
            self.theme_parameter(
                self.PHOTOS_THEME,
                self.tr("Photos page - theme for its map frame"),
                themes,
                multiple=False,
                optional=True,
            )
        )

    # ------------------------------------------------------------------ #

    @staticmethod
    def photos_page_number(run):
        """One past the highest 'Εικόνα N' in the run's titles, else pages + 1."""
        titles = run.themes + run.transparent_themes
        highest = ThemeLayoutsAlgorithm.highest_image_number(titles)
        return (highest if highest is not None else len(titles)) + 1

    @staticmethod
    def number_labels(layout, number, feedback):
        """Swap the '[]' placeholder for the @image_number expression.

        Returns the resolved text of the first such label, for the layout name.
        """
        QgsExpressionContextUtils.setLayoutVariable(layout, "image_number", number)
        title = None
        for item in layout.items():
            if not isinstance(item, QgsLayoutItemLabel):
                continue
            text = item.text()
            if NUMBER_PLACEHOLDER not in text:
                continue
            item.setText(text.replace(NUMBER_PLACEHOLDER, NUMBER_EXPRESSION))
            if title is None:
                title = text.replace(NUMBER_PLACEHOLDER, str(number)).strip()
        if title is None:
            feedback.pushWarning(
                "The photos template has no label with a '{}' placeholder.".format(NUMBER_PLACEHOLDER)
            )
        return title

    def after_pages(self, run):
        template_path = self.require_template(self.PHOTOS_TEMPLATE_FILE)

        theme = self.enum_string(run.parameters, self.PHOTOS_THEME, run.context)
        if theme:
            run.check_theme(theme)

        number = self.photos_page_number(run)
        fallback_extent = run.first_extent if run.first_extent is not None else run.shared_extent()
        feedback = run.feedback
        feedback.pushInfo("Creating the photos page as Εικόνα {}".format(number))

        try:
            layout = self.load_page(run.project, template_path, "", feedback)

            title = self.number_labels(layout, number, feedback)
            if not title:
                title = "Εικόνα {}: Ενδεικτικές Φωτογραφίες".format(number)
            layout.setName(title)
            feedback.pushInfo("Creating layout: {}".format(title))

            frame = self.main_map(layout)
            if frame is None:
                raise QgsProcessingException("The photos template has no map item.")
            if theme:
                frame.setFollowVisibilityPreset(True)
                frame.setFollowVisibilityPresetName(theme)
                extent = self.bookmark_extent(run.project, theme, run.map_crs) or fallback_extent
                feedback.pushInfo("Map frame: '{}'".format(theme))
            else:
                frame.setFollowVisibilityPreset(False)
                extent = fallback_extent
                feedback.pushInfo("Map frame: no theme - follows the live map")
            if extent is not None:
                frame.zoomToExtent(extent)

            QgsExpressionContextUtils.setLayoutVariable(layout, "layout_title", title)
            layout.refresh()
            self.add_to_project(run.project, layout, feedback)
            feedback.pushInfo(
                "'{}' created for the photographs to be added by hand - not exported.".format(title)
            )
        except QgsProcessingException:
            raise
        except Exception as exc:  # noqa: BLE001 - the page must not sink the run
            feedback.pushWarning("Photos page failed: {}".format(exc))
