# -*- coding: utf-8 -*-

"""
/***************************************************************************
 PantkaraTools
                                 A QGIS plugin
 Tools for Pantkara org
                              -------------------
        begin                : 2026-08-10
        copyright            : (C) 2026 by Alexandros Voukenas
        email                : alexandros@pkarapatsios.gr
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

Helpers shared by the Pantkara processing algorithms.
"""

__author__ = 'Alexandros Voukenas'
__date__ = '2026-08-10'
__copyright__ = '(C) 2026 by Alexandros Voukenas'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os

from qgis.core import (
    Qgis,
    QgsProcessingAlgorithm,
    QgsProcessingLayerPostProcessorInterface,
    QgsProject,
    QgsUnitTypes,
)

TEMPLATES_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "template data")


def algorithm_flag(name):
    """Return an algorithm flag, tolerating the QGIS 3.36 enum rename."""
    flag = getattr(QgsProcessingAlgorithm, "Flag" + name, None)
    if flag is None:
        flag = getattr(Qgis.ProcessingAlgorithmFlag, name)
    return flag


def crs_is_metric(crs):
    """True when the CRS measures in metres, across the 3.30 unit-enum rename."""
    metres = getattr(getattr(Qgis, "DistanceUnit", None), "Meters", None)
    if metres is None:
        metres = QgsUnitTypes.DistanceMeters
    return crs.mapUnits() == metres


class StylePostProcessor(QgsProcessingLayerPostProcessorInterface):
    """Styles a result layer from a .qml, optionally renaming and repositioning it.

    Processing keeps only a weak reference to post-processors, so every
    instance is parked in `instances` for the lifetime of the algorithm run.
    """

    instances = []

    def __init__(self, qml_file, layer_name=None, below_layer_id=None):
        super().__init__()
        self.qml_path = os.path.join(TEMPLATES_FOLDER, qml_file)
        self.layer_name = layer_name
        self.below_layer_id = below_layer_id
        StylePostProcessor.instances.append(self)

    def postProcessLayer(self, layer, context, feedback):
        if layer is None or not layer.isValid():
            return

        if self.layer_name:
            layer.setName(self.layer_name)

        if os.path.exists(self.qml_path):
            message, ok = layer.loadNamedStyle(self.qml_path)
            if ok:
                feedback.pushInfo(
                    "Applied symbology from {}".format(os.path.basename(self.qml_path))
                )
            else:
                feedback.pushWarning(
                    "Could not apply {}: {}".format(os.path.basename(self.qml_path), message)
                )
            layer.triggerRepaint()
        else:
            feedback.pushWarning(
                "Symbology file not found at: {}. Layer added unstyled.".format(self.qml_path)
            )

        if self.below_layer_id:
            self.move_below(layer, context, feedback)

    def move_below(self, layer, context, feedback):
        project = context.project() or QgsProject.instance()
        if project is None:
            return

        root = project.layerTreeRoot()
        node = root.findLayer(layer.id())
        anchor = root.findLayer(self.below_layer_id)
        if node is None or anchor is None:
            feedback.pushInfo(
                "'{}' added at the top of the layer tree "
                "(the layer it should sit under was not found).".format(layer.name())
            )
            return

        parent = anchor.parent()
        try:
            position = parent.children().index(anchor)
        except ValueError:
            return

        clone = node.clone()
        parent.insertChildNode(position + 1, clone)
        node.parent().removeChildNode(node)
        feedback.pushInfo(
            "Placed '{}' below '{}'.".format(layer.name(), anchor.name())
        )


def register_style_post_processor(context, layer_id, qml_file,
                                  layer_name=None, below_layer_id=None):
    """Attach a StylePostProcessor to a sink output being loaded on completion."""
    if not layer_id or layer_id not in context.layersToLoadOnCompletion():
        return
    details = context.layerToLoadOnCompletionDetails(layer_id)
    if layer_name:
        details.name = layer_name
    details.setPostProcessor(
        StylePostProcessor(qml_file, layer_name=layer_name, below_layer_id=below_layer_id)
    )
