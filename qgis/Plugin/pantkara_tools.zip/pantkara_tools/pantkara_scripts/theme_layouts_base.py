# -*- coding: utf-8 -*-

"""
/***************************************************************************
 PantkaraTools
                                 A QGIS plugin
 Tools for Pantkara org
                              -------------------
        begin                : 2026-09-16
        copyright            : (C) 2026 by Alexandros Voukenas
        email                : alexandros@pkarapatsios.gr
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

Shared engine of the Generate Layouts tools.

The page composition (logo, north arrow, scale bar, legend, title) lives in a
.qpt template; what each page shows is a map theme, and the theme's name is
the page's full title. For every chosen theme the tool loads the template,
locks its map to the theme, zooms it to the bookmark of the same name (both
made by Save Layout View), rebuilds the legend from the theme's vector
layers, writes the title into the template's empty label, adds it to the
project and exports a 300 dpi PNG. Transparent themes get the same treatment
with every decoration stripped and a see-through page.

Subclasses add the case-specific extra page (DA: the four-frame temporal
page; PROD: the indicative-photos page) through the hooks at the bottom.
"""

__author__ = 'Alexandros Voukenas'
__date__ = '2026-09-16'
__copyright__ = '(C) 2026 by Alexandros Voukenas'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os
import re
from types import SimpleNamespace

from osgeo import gdal
from qgis.PyQt.QtCore import QCoreApplication, QUrl
from qgis.PyQt.QtGui import QDesktopServices
from qgis.PyQt.QtXml import QDomDocument
from qgis.core import (
    QgsCoordinateTransform,
    QgsExpressionContextUtils,
    QgsFillSymbol,
    QgsLayoutExporter,
    QgsLayoutItem,
    QgsLayoutItemLabel,
    QgsLayoutItemLegend,
    QgsLayoutItemMap,
    QgsLayoutItemPage,
    QgsLayoutItemPicture,
    QgsMapLayer,
    QgsPathResolver,
    QgsPrintLayout,
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingException,
    QgsProcessingParameterDefinition,
    QgsProcessingParameterEnum,
    QgsProcessingParameterExtent,
    QgsProcessingParameterFile,
    QgsProcessingParameterNumber,
    QgsProcessingParameterVectorLayer,
    QgsProject,
    QgsReadWriteContext,
    QgsRectangle,
)

from .common import TEMPLATES_FOLDER, algorithm_flag

# Sub-folder of the project directory the exports default to.
DEFAULT_OUTPUT_SUBFOLDER = "Layouts"

# The parcel layer is recognised by this field, added by Convert from CAD, and
# is always labelled this way in the legend whatever the layer is called.
PARCEL_FIELD = "parcel"
PARCEL_LEGEND_NAME = "ΓΕΩΤΕΜΑΧΙΟ"

EXPORT_DPI = 300

# Characters Windows will not accept in a file name. A colon is the important
# one: 'Εικόνα 1: …' would otherwise be written into an NTFS alternate data
# stream and appear to succeed while producing nothing.
ILLEGAL_FILENAME_CHARS = re.compile(r'[<>:"/\\|?*]')

# Titles follow the report's figure numbering; this is how the number is read
# back out of a theme name.
IMAGE_NUMBER = re.compile(r"Εικόνα\s*(\d+)", re.IGNORECASE)


class ThemeLayoutsAlgorithm(QgsProcessingAlgorithm):
    """Base class: one layout per map theme, from a template."""

    OUT_FOLDER = "OUT_FOLDER"
    THEMES = "THEMES"
    EXTENT = "EXTENT"
    TRANSPARENT_THEMES = "TRANSPARENT_THEMES"
    EXTENT_MARGIN = "EXTENT_MARGIN"
    PARCEL_LAYER = "PARCEL_LAYER"

    # Subclasses set these. Templates are fixtures of the tool, not inputs:
    # they live in the plugin's 'template data' folder under fixed names and
    # are edited there by the developer.
    ALGORITHM_ID = ""
    DISPLAY_NAME = ""
    TEMPLATE_FILE = ""

    def tr(self, string):
        return QCoreApplication.translate(type(self).__name__, string)

    def createInstance(self):
        return type(self)()

    def name(self):
        return self.ALGORITHM_ID

    def displayName(self):
        return self.tr(self.DISPLAY_NAME)

    def group(self):
        return self.tr("Layouts")

    def groupId(self):
        return "Layouts"

    def flags(self):
        # Layouts are added to the project's layout manager, so the algorithm
        # must stay on the main thread and needs a project.
        return (
            super().flags()
            | algorithm_flag("NoThreading")
            | algorithm_flag("RequiresProject")
        )

    def shortHelpString(self):
        return self.tr(
            "{purpose}\n\n"
            "HOW IT WORKS\n"
            "One layout is built per selected view (a map theme saved with "
            "Save Layout View) from the tool's page template, added to the "
            "project and exported as a {dpi} dpi PNG. The view's name is the "
            "page's full title - it names the layout, is written into the "
            "title label and names the PNG. The map is locked to the theme "
            "and zoomed to the bookmark of the same name. The legend lists "
            "the theme's vector layers, with the parcel always labelled "
            "{parcel}.\n\n"
            "INPUTS\n"
            "• Output folder - '<project>/Layouts' by default; created if "
            "missing and opened when the run finishes.\n"
            "• Map themes - the views to build, one page each.\n"
            "• Map extent - only used by views that have no bookmark; blank "
            "means the parcel layer's extent plus the margin.\n"
        ).format(purpose=self.purpose(), dpi=EXPORT_DPI, parcel=PARCEL_LEGEND_NAME) + self.extra_help() + self.tr(
            "\nADVANCED\n"
            "• Transparent themes - views exported as map-only pages with no "
            "frame, no decorations and a see-through background, for use as "
            "overlays.\n"
            "• Margin / parcel layer - control the fallback extent.\n\n"
            "NOTES\n"
            "• A layout with the same name is replaced on every run. "
            "Generated layouts are disposable - keep hand-made changes in the "
            "template, not in the layout.\n"
            "• Colons are allowed in titles; they become underscores in the "
            "file names.\n"
            "• Variables available in the template: @layout_title, "
            "@theme_name and the built-in @layout_name."
        )

    def purpose(self):
        """One-line description of what the subclass produces."""
        return self.tr("Builds and exports the report pages from saved layout views.")

    # ------------------------------------------------------------------ #
    # hooks for subclasses
    # ------------------------------------------------------------------ #

    def extra_help(self):
        """Input bullets and notes for the subclass's extra page."""
        return ""

    def add_main_parameters(self, themes):
        """Add parameters shown in the main section, after the extent."""

    def extra_advanced_parameters(self, themes):
        """Parameters to add at the top of the Advanced section."""
        return []

    def after_pages(self, run):
        """Build the subclass's extra page(s) once the themed pages are done."""

    # ------------------------------------------------------------------ #
    # parameters
    # ------------------------------------------------------------------ #

    @staticmethod
    def default_output_folder():
        """<project folder>/Layouts, or nothing when the project is unsaved."""
        project = QgsProject.instance()
        home = project.homePath() if project else ""
        if not home:
            return None
        return os.path.join(home, DEFAULT_OUTPUT_SUBFOLDER)

    @staticmethod
    def project_theme_names():
        project = QgsProject.instance()
        if project is None:
            return []
        return list(project.mapThemeCollection().mapThemes())

    @staticmethod
    def template_path(filename):
        """Absolute path of a template in the plugin's 'template data' folder."""
        return os.path.join(TEMPLATES_FOLDER, filename)

    def require_template(self, filename):
        """The template's path, or a clear error naming the missing file."""
        path = self.template_path(filename)
        if not os.path.exists(path):
            raise QgsProcessingException(
                self.tr("Layout template missing from the plugin: {}").format(path)
            )
        return path

    def theme_parameter(self, name, description, themes, multiple=True, optional=False):
        return QgsProcessingParameterEnum(
            name,
            description,
            options=themes,
            allowMultiple=multiple,
            usesStaticStrings=True,
            optional=optional,
        )

    def initAlgorithm(self, config=None):
        themes = self.project_theme_names()

        # A folder *input* rather than a folder destination: destination
        # parameters are always rendered at the bottom of the dialog, and this
        # one belongs at the top. A folder that does not exist yet is still an
        # acceptable value, and it is created when the algorithm runs.
        self.addParameter(
            QgsProcessingParameterFile(
                self.OUT_FOLDER,
                self.tr("Output folder"),
                behavior=QgsProcessingParameterFile.Folder,
                defaultValue=self.default_output_folder(),
            )
        )
        self.addParameter(
            self.theme_parameter(self.THEMES, self.tr("Map themes - one layout each"), themes)
        )
        self.addParameter(
            QgsProcessingParameterExtent(
                self.EXTENT,
                self.tr("Map extent (blank: parcel layer extent plus margin)"),
                optional=True,
            )
        )
        self.add_main_parameters(themes)

        advanced = list(self.extra_advanced_parameters(themes)) + [
            self.theme_parameter(
                self.TRANSPARENT_THEMES,
                self.tr("Map themes exported as transparent, map-only pages"),
                themes,
                optional=True,
            ),
            QgsProcessingParameterNumber(
                self.EXTENT_MARGIN,
                self.tr("Margin around the parcel extent (%)"),
                type=QgsProcessingParameterNumber.Double,
                defaultValue=25.0,
                minValue=0.0,
            ),
            QgsProcessingParameterVectorLayer(
                self.PARCEL_LAYER,
                self.tr("Parcel layer (blank: first layer with a '{}' field)").format(
                    PARCEL_FIELD
                ),
                [QgsProcessing.TypeVectorPolygon],
                optional=True,
            ),
        ]
        for parameter in advanced:
            parameter.setFlags(parameter.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
            self.addParameter(parameter)

    # ------------------------------------------------------------------ #
    # parameter reading
    # ------------------------------------------------------------------ #

    def enum_strings(self, parameters, name, context):
        """Selected values of a static-string enum, read from the raw parameter.

        parameterAsEnumStrings() splits every value on commas before checking
        it against the options, so a theme called 'Εικόνα 3: Γεωτεμάχιο,
        Επίδικο Τμήμα' is torn into fragments that match nothing - and QGIS
        then discards the entire selection. It also returns [''] for an empty
        optional parameter. Reading the value directly avoids both.
        """
        value = parameters.get(name)
        if value is None:
            return []
        if isinstance(value, str):
            options = self.parameterDefinition(name).options()
            if value in options:
                values = [value]
            else:
                # A scripted call may join several names; ';' is the only
                # separator that cannot appear in a theme name we control.
                values = value.split(";")
        else:
            try:
                values = [str(v) for v in value]
            except TypeError:
                values = [str(value)]
        return [v.strip() for v in values if v and str(v).strip()]

    def enum_string(self, parameters, name, context):
        """First selected value of a static-string enum, or None."""
        values = self.enum_strings(parameters, name, context)
        return values[0] if values else None

    # ------------------------------------------------------------------ #
    # helpers
    # ------------------------------------------------------------------ #

    @staticmethod
    def safe_filename(name):
        return ILLEGAL_FILENAME_CHARS.sub("_", name).strip().rstrip(".") or "layout"

    @staticmethod
    def highest_image_number(names):
        """Largest 'Εικόνα N' found in the given titles, or None."""
        numbers = [int(m.group(1)) for name in names for m in [IMAGE_NUMBER.search(name)] if m]
        return max(numbers) if numbers else None

    @staticmethod
    def find_parcel_layer(project):
        """First vector layer carrying the parcel marker field."""
        for layer in project.mapLayers().values():
            if layer.type() != QgsMapLayer.VectorLayer:
                continue
            if any(field.name().lower() == PARCEL_FIELD for field in layer.fields()):
                return layer
        return None

    @staticmethod
    def load_template(project, template_path):
        """A fresh QgsPrintLayout populated from the .qpt file."""
        document = QDomDocument()
        with open(template_path, "rb") as handle:
            ok, message, _line, _column = document.setContent(handle.read())
        if not ok:
            raise QgsProcessingException("Template is not valid XML: {}".format(message))

        # No initializeDefaults(): the template brings its own page, and the
        # default page would be left orphaned in the scene - invisible to
        # pageCollection() but still painted, opaque white, over the export.
        layout = QgsPrintLayout(project)

        context = QgsReadWriteContext()
        context.setPathResolver(QgsPathResolver(template_path))
        _items, ok = layout.loadFromTemplate(document, context, True)
        if not ok:
            raise QgsProcessingException(
                "Could not load the layout template {}".format(template_path)
            )
        return layout

    @staticmethod
    def repoint_pictures(layout, template_dir, feedback):
        """Point picture items at files beside the template when their own path is dead.

        The .qpt was saved with the logo path relative to some project; when
        it does not resolve, a file of the same name next to the template wins.
        """
        for item in layout.items():
            if not isinstance(item, QgsLayoutItemPicture):
                continue
            path = item.picturePath()
            if not path or os.path.exists(path):
                continue
            candidate = os.path.join(template_dir, os.path.basename(path))
            if os.path.exists(candidate):
                item.setPicturePath(candidate)
                feedback.pushInfo("Picture repointed to {}".format(candidate))

    def load_page(self, project, template_path, name, feedback):
        """Template loaded, pictures repointed and the layout named."""
        layout = self.load_template(project, template_path)
        self.repoint_pictures(layout, os.path.dirname(os.path.abspath(template_path)), feedback)
        layout.setName(name)
        return layout

    @staticmethod
    def map_items(layout):
        """The layout's map items in reading order: top-left first."""
        maps = [item for item in layout.items() if isinstance(item, QgsLayoutItemMap)]
        maps.sort(key=lambda m: (round(m.pos().y(), 1), round(m.pos().x(), 1)))
        return maps

    @staticmethod
    def main_map(layout):
        maps = [item for item in layout.items() if isinstance(item, QgsLayoutItemMap)]
        if not maps:
            return None
        # The template's own map - largest by area, in case a template carries
        # an inset as well.
        return max(maps, key=lambda m: m.rect().width() * m.rect().height())

    @staticmethod
    def bookmark_extent(project, theme, map_crs):
        """Extent of the project bookmark named after the theme, in map_crs; else None.

        Save Layout View writes a theme and a bookmark under the same name -
        this is the other half of that pairing.
        """
        wanted = theme.strip().casefold()
        for bookmark in project.bookmarkManager().bookmarks():
            if bookmark.name().strip().casefold() != wanted:
                continue
            extent = bookmark.extent()
            rect = QgsRectangle(extent)
            if extent.crs().isValid() and extent.crs() != map_crs:
                transform = QgsCoordinateTransform(extent.crs(), map_crs, project.transformContext())
                rect = transform.transformBoundingBox(rect)
            if not rect.isNull() and not rect.isEmpty():
                return rect
        return None

    def resolve_extent(self, parameters, context, map_item, project, feedback):
        """The fallback extent for themes without a bookmark, in the map item's CRS."""
        map_crs = map_item.crs()
        if not map_crs.isValid():
            map_crs = project.crs()

        if parameters.get(self.EXTENT) not in (None, ""):
            extent = self.parameterAsExtent(parameters, self.EXTENT, context, map_crs)
            if not extent.isNull() and not extent.isEmpty():
                feedback.pushInfo("Extent from parameter: {}".format(extent.toString(2)))
                return extent
            feedback.pushWarning("The extent parameter is empty - falling back to the parcel layer.")

        parcels = self.parameterAsVectorLayer(parameters, self.PARCEL_LAYER, context)
        if parcels is None:
            parcels = self.find_parcel_layer(project)
        if parcels is None:
            raise QgsProcessingException(
                self.tr(
                    "No extent given and no parcel layer found (a vector layer "
                    "with a '{}' field)."
                ).format(PARCEL_FIELD)
            )

        extent = QgsRectangle(parcels.extent())
        if parcels.crs() != map_crs:
            transform = QgsCoordinateTransform(parcels.crs(), map_crs, project.transformContext())
            extent = transform.transformBoundingBox(extent)
        if extent.isNull() or extent.isEmpty():
            raise QgsProcessingException(
                self.tr("The parcel layer '{}' has no extent.").format(parcels.name())
            )

        margin = self.parameterAsDouble(parameters, self.EXTENT_MARGIN, context) / 100.0
        extent.grow(max(extent.width(), extent.height()) * margin)
        feedback.pushInfo(
            "Extent from '{}' plus {:.0f}%: {}".format(parcels.name(), margin * 100, extent.toString(2))
        )
        return extent

    @staticmethod
    def fill_title(layout, title, feedback, required=True):
        """Write the title into the template's blank label(s).

        The template's title label is left empty on purpose; any label that
        already carries text is part of the design and is not touched. With
        required=False a template that carries its own title is fine.
        """
        filled = 0
        for item in layout.items():
            if isinstance(item, QgsLayoutItemLabel) and not item.text().strip():
                item.setText(title)
                filled += 1
        if not filled and required:
            feedback.pushWarning(
                "The template has no empty label to receive the title '{}'.".format(title)
            )

    @staticmethod
    def rebuild_legend(legend, theme_layers, parcel_layer):
        """Legend entries = the theme's vector layers, parcel labelled ΓΕΩΤΕΜΑΧΙΟ."""
        legend.setAutoUpdateModel(False)
        root = legend.model().rootGroup()
        root.removeAllChildren()
        for layer in theme_layers:
            if layer.type() != QgsMapLayer.VectorLayer:
                continue
            node = root.addLayer(layer)
            if parcel_layer is not None and layer.id() == parcel_layer.id():
                node.setName(PARCEL_LEGEND_NAME)
        legend.setLegendFilterByMapEnabled(True)
        legend.updateLegend()

    @staticmethod
    def make_transparent(layout, map_item):
        """Strip the page down to the map on a see-through background."""
        for item in list(layout.items()):
            if not isinstance(item, QgsLayoutItem):
                continue
            if item is map_item or isinstance(item, QgsLayoutItemPage):
                continue
            layout.removeLayoutItem(item)
        map_item.setFrameEnabled(False)
        map_item.setBackgroundEnabled(False)

        # A page saved in a template carries its own style symbol, which wins
        # over the collection-level one, so the see-through fill has to go on
        # every page as well.
        pages = layout.pageCollection()
        pages.setPageStyleSymbol(
            QgsFillSymbol.createSimple({"color": "0,0,0,0", "outline_style": "no"})
        )
        for index in range(pages.pageCount()):
            pages.page(index).setPageStyleSymbol(
                QgsFillSymbol.createSimple({"color": "0,0,0,0", "outline_style": "no"})
            )

    @staticmethod
    def add_to_project(project, layout, feedback):
        """Put the layout in the layout manager, replacing a same-named one."""
        manager = project.layoutManager()
        existing = manager.layoutByName(layout.name())
        if existing is not None:
            manager.removeLayout(existing)
            feedback.pushInfo("Replaced existing layout: {}".format(layout.name()))
        manager.addLayout(layout)

    @staticmethod
    def export_png(layout, png_path):
        """Export the layout to PNG at EXPORT_DPI, without georeferencing.

        The figures are report images, not map data, so no world file or
        embedded georeference. QgsLayoutExporter nevertheless always reopens
        the written file through GDAL in update mode to stamp metadata, which
        the PNG driver refuses with 'does not support update access' - a
        harmless message that would otherwise land in the log for every
        page, so GDAL is kept quiet for the duration of the export.
        """
        layout.setReferenceMap(None)
        settings = QgsLayoutExporter.ImageExportSettings()
        settings.dpi = EXPORT_DPI
        settings.exportMetadata = False
        settings.generateWorldFile = False

        gdal.PushErrorHandler("CPLQuietErrorHandler")
        try:
            return QgsLayoutExporter(layout).exportToImage(png_path, settings)
        finally:
            gdal.PopErrorHandler()

    def export_page(self, layout, run):
        """Export the layout as <safe name>.png into the run's folder."""
        png_path = os.path.join(run.out_folder, self.safe_filename(layout.name()) + ".png")
        result = self.export_png(layout, png_path)
        if result == QgsLayoutExporter.Success:
            run.feedback.pushInfo("PNG exported: {}".format(png_path))
            run.exported.append(png_path)
        else:
            run.feedback.pushWarning(
                "PNG export failed for '{}' (code {}).".format(layout.name(), int(result))
            )

    # ------------------------------------------------------------------ #
    # main
    # ------------------------------------------------------------------ #

    def processAlgorithm(self, parameters, context, feedback):
        project = context.project() or QgsProject.instance()
        if project is None:
            raise QgsProcessingException(self.tr("This tool needs an open project."))

        out_folder = self.parameterAsFile(parameters, self.OUT_FOLDER, context)
        if not out_folder:
            raise QgsProcessingException(self.tr("Choose an output folder."))
        os.makedirs(out_folder, exist_ok=True)
        feedback.pushInfo("Output folder: {}".format(out_folder))

        template_path = self.require_template(self.TEMPLATE_FILE)
        feedback.pushInfo("Template: {}".format(os.path.basename(template_path)))

        themes = self.enum_strings(parameters, self.THEMES, context)
        transparent_themes = self.enum_strings(parameters, self.TRANSPARENT_THEMES, context)
        if not themes and not transparent_themes:
            raise QgsProcessingException(
                self.tr("Select at least one map theme (the project has: {}).").format(
                    ", ".join(self.project_theme_names()) or self.tr("none")
                )
            )

        theme_collection = project.mapThemeCollection()

        parcel_layer = self.parameterAsVectorLayer(parameters, self.PARCEL_LAYER, context)
        if parcel_layer is None:
            parcel_layer = self.find_parcel_layer(project)
        feedback.pushInfo(
            "Parcel layer: {}".format(parcel_layer.name() if parcel_layer else "not found")
        )

        # A throwaway copy of the template tells us the map CRS up front.
        probe = self.load_template(project, template_path)
        probe_map = self.main_map(probe)
        if probe_map is None:
            raise QgsProcessingException(self.tr("The template has no map item."))
        map_crs = probe_map.crs() if probe_map.crs().isValid() else project.crs()

        run = SimpleNamespace(
            project=project,
            parameters=parameters,
            context=context,
            feedback=feedback,
            out_folder=out_folder,
            themes=themes,
            transparent_themes=transparent_themes,
            theme_collection=theme_collection,
            parcel_layer=parcel_layer,
            map_crs=map_crs,
            first_extent=None,   # the first page's extent - extra pages' fallback
            exported=[],
        )
        shared = {"extent": None}  # resolved lazily: only themes without a bookmark need it

        def shared_extent():
            if shared["extent"] is None:
                shared["extent"] = self.resolve_extent(parameters, context, probe_map, project, feedback)
            return shared["extent"]

        run.shared_extent = shared_extent

        def check_theme(theme):
            if not theme_collection.hasMapTheme(theme):
                raise QgsProcessingException(
                    self.tr("The project has no map theme called '{}'.").format(theme)
                )

        run.check_theme = check_theme
        for theme in themes + transparent_themes:
            check_theme(theme)

        jobs = [(theme, False) for theme in themes] + [(theme, True) for theme in transparent_themes]
        total = len(jobs)

        for position, (theme, transparent) in enumerate(jobs):
            if feedback.isCanceled():
                break
            feedback.setProgress(int(position * 100.0 / total))
            feedback.pushInfo("Creating layout: {} (transparent={})".format(theme, transparent))

            try:
                layout = self.load_page(project, template_path, theme, feedback)

                map_item = self.main_map(layout)
                map_item.setFollowVisibilityPreset(True)
                map_item.setFollowVisibilityPresetName(theme)

                extent = self.bookmark_extent(project, theme, map_crs)
                if extent is not None:
                    feedback.pushInfo("Extent from bookmark: {}".format(extent.toString(2)))
                else:
                    feedback.pushInfo("No bookmark named '{}' - using the shared extent.".format(theme))
                    extent = shared_extent()
                map_item.zoomToExtent(extent)
                if run.first_extent is None:
                    run.first_extent = QgsRectangle(extent)

                theme_layers = theme_collection.mapThemeVisibleLayers(theme)
                for item in layout.items():
                    if isinstance(item, QgsLayoutItemLegend):
                        item.setLinkedMap(map_item)
                        self.rebuild_legend(item, theme_layers, parcel_layer)

                if transparent:
                    self.make_transparent(layout, map_item)
                else:
                    self.fill_title(layout, theme, feedback)

                QgsExpressionContextUtils.setLayoutVariable(layout, "layout_title", theme)
                QgsExpressionContextUtils.setLayoutVariable(layout, "theme_name", theme)
                layout.refresh()

                self.add_to_project(project, layout, feedback)
                self.export_page(layout, run)
            except QgsProcessingException:
                raise
            except Exception as exc:  # noqa: BLE001 - one bad page must not stop the run
                feedback.pushWarning("Layout '{}' failed: {}".format(theme, exc))

        if not feedback.isCanceled():
            self.after_pages(run)

        feedback.setProgress(100)
        feedback.pushInfo(
            "Finished: {} layout(s) exported to {}".format(len(run.exported), out_folder)
        )

        # Open the folder in the file manager, as the ArcGIS tool did with
        # os.startfile - but through Qt, so it works on any platform.
        if run.exported and not QDesktopServices.openUrl(QUrl.fromLocalFile(out_folder)):
            feedback.pushWarning("Could not open the output folder: {}".format(out_folder))

        return {self.OUT_FOLDER: out_folder}
