# -*- coding: utf-8 -*-

"""
/***************************************************************************
 PantkaraTools
                                 A QGIS plugin
 Tools for Pantkara org
                              -------------------
        begin                : 2026-10-01
        copyright            : (C) 2026 by Alexandros Voukenas
        email                : alexandros@pkarapatsios.gr
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

Shared pieces of the "Antirrisi to polygon" tools, the QGIS equivalent of
other-tools/Antirrisi to polygon.ipynb (ArcGIS).

An αντίρρηση arrives as a PDF listing the vertices of a parcel; the two tools
make the layer that receives them and then insert one polygon per αντίρρηση.
"""

__author__ = 'Alexandros Voukenas'
__date__ = '2026-10-01'
__copyright__ = '(C) 2026 by Alexandros Voukenas'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os
import re

from qgis.PyQt.QtCore import QVariant
from qgis.core import QgsField, QgsFields

GROUP_NAME = "Antirrisi to polygon"

# Where the αντιρρήσεις layers live: <project folder>/Analysis/analysis.gpkg.
ANALYSIS_SUBFOLDER = "Analysis"
ANALYSIS_GEOPACKAGE = "analysis.gpkg"

# The αντιρρήσεις are always in ΕΓΣΑ87.
TARGET_CRS = "EPSG:2100"

# Field name -> (type, alias). Mirrors the AddFields call in the notebook.
ANTIRRISI_FIELDS = [
    ("aa_old", QVariant.Int, "Α.Α. ΑΡΧΙΚΟ"),
    ("aa_new", QVariant.Int, "Α.Α. ΝΕΟ"),
    ("emvadon", QVariant.Double, "Εμβαδόν"),
    ("new_proteuon", QVariant.String, "Νέος Πρωτεύων"),
    ("new_deutereuon", QVariant.String, "Νέος Δευτερεύων"),
    ("new_triteuon", QVariant.String, "Νέος Τριτεύων"),
    ("new_landtype", QVariant.String, "Νέο Landtype"),
]

# The field the symbology and the labels classify on.
CATEGORY_FIELD = "new_proteuon"

# 'X1=631342,970 Y1=4106531,850' - the form the PDFs use. The decimal
# separator is a comma there, but a full stop is accepted just as well.
VERTEX = re.compile(
    r"X\d+\s*=\s*(\d+(?:[.,]\d+)?)\s+Y\d+\s*=\s*(\d+(?:[.,]\d+)?)",
    re.IGNORECASE,
)


def analysis_geopackage(project):
    """<project folder>/Analysis/analysis.gpkg, or None for an unsaved project."""
    home = project.homePath() if project else ""
    if not home:
        return None
    return os.path.join(home, ANALYSIS_SUBFOLDER, ANALYSIS_GEOPACKAGE)


def antirrisi_fields():
    """The QgsFields an αντιρρήσεις layer is created with."""
    fields = QgsFields()
    for name, field_type, _alias in ANTIRRISI_FIELDS:
        fields.append(QgsField(name, field_type))
    return fields


def parse_vertices(text):
    """[(x, y), …] read from a PDF coordinate block.

    Returns the points in the order they are listed; the closing vertex is
    left exactly as written, so a block that already repeats the first point
    is not given a second one.
    """
    points = []
    for match in VERTEX.finditer(text or ""):
        x = float(match.group(1).replace(",", "."))
        y = float(match.group(2).replace(",", "."))
        points.append((x, y))
    return points
