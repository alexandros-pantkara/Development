# -*- coding: utf-8 -*-

"""
/***************************************************************************
 PantkaraTools
                                 A QGIS plugin
 Tools for Pantkara org
                              -------------------
        begin                : 2026-08-10
        copyright            : (C) 2026 by Alexandros Voukenas
        email                : alexandros@pkarapatsios.gr
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

QGIS equivalent of Parcel-analysis-and-layouts/summarize_polygons.py (ArcGIS).

Summarises forest-cover categories inside cadastral parcels, writes the summary
back onto the parcel layer and to CSV, then produces the two derived layers:

  * ΕΠΙΔΙΚΟ_ΤΜΗΜΑ          - parcels intersected with the disputed categories
  * ΓΕΩΤΕΜΑΧΙΟ_ΜΟΡΦΕΣ_ΔΧ   - forest cover clipped to the parcels

Both are styled from the .qml templates in `template data` and inserted below
the parcel layer in the layer tree.
"""

__author__ = 'Alexandros Voukenas'
__date__ = '2026-08-10'
__copyright__ = '(C) 2026 by Alexandros Voukenas'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import csv
import os
import re

from qgis.PyQt.QtCore import QCoreApplication, QVariant
from qgis.core import (
    Qgis,
    QgsCoordinateTransform,
    QgsFeature,
    QgsFeatureRequest,
    QgsFeatureSink,
    QgsField,
    QgsFields,
    QgsGeometry,
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingException,
    QgsProcessingParameterCrs,
    QgsProcessingParameterEnum,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterFolderDestination,
    QgsProcessingParameterString,
    QgsProcessingParameterVectorLayer,
    QgsRectangle,
    QgsSpatialIndex,
    QgsVectorDataProvider,
    QgsWkbTypes,
)

from .common import (
    StylePostProcessor,
    algorithm_flag,
    crs_is_metric,
    register_style_post_processor,
)

# The three forest-cover fields the ArcGIS tool accepts, in the order the
# original iterated them.
SUMMARY_FIELDS = ["KATHGORDX", "KATHGORAL1", "LANDTYPE"]

# KATHGORDX categories, taken from the categorised renderer in ΔΑΣΙΚΟΣ.qml.
KATHGORDX_VALUES = ["ΑΑ", "ΑΔ", "ΔΑ", "ΔΔ", "ΠΑ", "ΠΔ", "ΠΧ", "ΧΑ", "ΧΧ"]

# Attributes ΕΠΙΔΙΚΟ_ΤΜΗΜΑ keeps from the forest layer (arcpy DeleteField
# KEEP_FIELDS list, minus the FID_<parcel> field which is added separately).
EPIDIKO_KEEP_FIELDS = ["NOMOS", "OTA", "KATHGORDX", "KATHGORAL1", "LANDTYPE"]

AREA_FIELD = "Εμβαδόν"


def polygonal_intersection(geom_a, geom_b):
    """Intersection of two geometries, reduced to its polygonal parts.

    Two polygons that only touch produce a line or a point; arcpy's Intersect
    with output_type="INPUT" discards those, so we do too.
    """
    result = geom_a.intersection(geom_b)
    if result.isNull() or result.isEmpty():
        return None

    parts = [part for part in result.asGeometryCollection()
             if part.type() == QgsWkbTypes.PolygonGeometry and not part.isEmpty()]
    if not parts:
        return None

    result = parts[0] if len(parts) == 1 else QgsGeometry.collectGeometry(parts)
    if result.isNull() or result.area() <= 0:
        return None
    return result



class SummarizePolygons(QgsProcessingAlgorithm):
    """Summarize forest cover within cadastral parcels."""

    PARCELS = "PARCELS"
    FOREST = "FOREST"
    FIELDS = "FIELDS"
    EPIDIKO_VALUES = "EPIDIKO_VALUES"
    TARGET_CRS = "TARGET_CRS"
    CSV_FOLDER = "CSV_FOLDER"
    FINAL_COLUMNS = "FINAL_COLUMNS"
    EPIDIKO_OUTPUT = "EPIDIKO_OUTPUT"
    CLIPPED_OUTPUT = "CLIPPED_OUTPUT"

    def tr(self, string):
        return QCoreApplication.translate("SummarizePolygons", string)

    def createInstance(self):
        return SummarizePolygons()

    def name(self):
        return "summarizepolygons"

    def displayName(self):
        return self.tr("Summarize Polygons (Intersect)")

    def group(self):
        return self.tr("Parcel Tools")

    def groupId(self):
        # Matches the id the sibling algorithms use, so they share one group
        # node in the toolbox.
        return "Parcel Tools"

    def flags(self):
        # The parcel layer is edited in place and the results are inserted into
        # the layer tree, so the algorithm must stay on the main thread.
        return (
            super().flags()
            | algorithm_flag("NoThreading")
            | algorithm_flag("RequiresProject")
        )

    def shortHelpString(self):
        return self.tr(
            "Measures the forest-map categories inside each parcel and builds "
            "the ΕΠΙΔΙΚΟ ΤΜΗΜΑ and ΜΟΡΦΕΣ ΔΧ layers.\n\n"
            "HOW IT WORKS\n"
            "For every selected forest-cover field, the area of each category "
            "inside each parcel is measured and written onto the parcel layer "
            "as one column per category, next to the parcel's own area "
            "(Εμβαδόν). Then two layers are made:\n"
            "• ΕΠΙΔΙΚΟ_ΤΜΗΜΑ - the parcels intersected with the forest "
            "polygons whose KATHGORDX is one of the chosen values;\n"
            "• ΓΕΩΤΕΜΑΧΙΟ_ΜΟΡΦΕΣ_ΔΧ - the forest cover clipped to the "
            "parcels.\n"
            "Both are styled from their templates and placed directly below "
            "the parcel layer.\n\n"
            "INPUTS\n"
            "• Cadastral polygons - the parcel layer; it is edited in place, "
            "so it must be editable.\n"
            "• Forest cover polygons - the forest map (KATHGORDX, KATHGORAL1, "
            "LANDTYPE).\n"
            "• Fields to summarise, and the KATHGORDX values that make up the "
            "ΕΠΙΔΙΚΟ ΤΜΗΜΑ.\n"
            "• Coordinate system for the areas - must be metric.\n"
            "• CSV output folder - receives 'Polygon Summary draft.csv' (the "
            "full table) and 'Polygon Summary final.csv' (ID, Εμβαδόν and the "
            "chosen columns).\n\n"
            "NOTES\n"
            "• Areas are in square metres of the chosen CRS, rounded to 3 "
            "decimals.\n"
            "• The output layers take a '_<layer name>' suffix when the parcel "
            "layer is not called ΓΕΩΤΕΜΑΧΙΟ."
        )

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.PARCELS,
                self.tr("Cadastral polygons (e.g. ΓΕΩΤΕΜΑΧΙΟ)"),
                [QgsProcessing.TypeVectorPolygon],
            )
        )
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.FOREST,
                self.tr("Forest cover polygons"),
                [QgsProcessing.TypeVectorPolygon],
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.FIELDS,
                self.tr("Forest cover fields to summarise"),
                options=SUMMARY_FIELDS,
                allowMultiple=True,
                defaultValue=SUMMARY_FIELDS,
                usesStaticStrings=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.EPIDIKO_VALUES,
                self.tr("KATHGORDX values that make up the ΕΠΙΔΙΚΟ ΤΜΗΜΑ"),
                options=KATHGORDX_VALUES,
                allowMultiple=True,
                defaultValue=[],
                usesStaticStrings=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterCrs(
                self.TARGET_CRS,
                self.tr("Coordinate system used for the area measurements"),
                defaultValue="EPSG:2100",
            )
        )
        self.addParameter(
            QgsProcessingParameterFolderDestination(
                self.CSV_FOLDER,
                self.tr("CSV output folder"),
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.FINAL_COLUMNS,
                self.tr(
                    "Columns to keep in 'Polygon Summary final.csv' "
                    "(semicolon separated; blank keeps them all)"
                ),
                defaultValue="",
                optional=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.EPIDIKO_OUTPUT,
                self.tr("ΕΠΙΔΙΚΟ ΤΜΗΜΑ"),
                QgsProcessing.TypeVectorPolygon,
            )
        )
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.CLIPPED_OUTPUT,
                self.tr("ΓΕΩΤΕΜΑΧΙΟ ΜΟΡΦΕΣ ΔΧ"),
                QgsProcessing.TypeVectorPolygon,
            )
        )

    # ------------------------------------------------------------------ #
    # helpers
    # ------------------------------------------------------------------ #

    @staticmethod
    def sanitise_field_name(raw_name, existing_names, max_length):
        """Field name that the parcel layer's provider will accept, deduplicated.

        The QGIS counterpart of arcpy.ValidateFieldName: category values become
        column names, and they can be numeric (LANDTYPE) or carry characters the
        provider rejects.
        """
        name = re.sub(r"[^0-9A-Za-z_Ͱ-Ͽἀ-῿]", "_", str(raw_name).strip())
        if not name:
            name = "VALUE"
        if name[0].isdigit():
            name = "F_" + name
        name = name[:max_length]

        candidate = name
        suffix = 1
        lowered = {n.lower() for n in existing_names}
        while candidate.lower() in lowered:
            tail = "_{}".format(suffix)
            candidate = name[: max(1, max_length - len(tail))] + tail
            suffix += 1
        return candidate

    @staticmethod
    def value_key(field_name, raw_value):
        """Normalise a category value, or None when the feature must be skipped.

        Mirrors the where-clauses the ArcGIS tool applied before summarising:
        KATHGORAL1 must not be blank and LANDTYPE must not be 0.
        """
        if raw_value is None or (isinstance(raw_value, QVariant) and raw_value.isNull()):
            return None

        if field_name == "LANDTYPE":
            try:
                numeric = int(raw_value)
            except (TypeError, ValueError):
                return None
            return None if numeric == 0 else str(numeric)

        text = str(raw_value).strip()
        if not text:
            return None
        if field_name == "KATHGORAL1" and text == "":
            return None
        return text

    def build_output_names(self, parcel_layer_name):
        """ΕΠΙΔΙΚΟ_ΤΜΗΜΑ / ΓΕΩΤΕΜΑΧΙΟ_ΜΟΡΦΕΣ_ΔΧ, suffixed for non-standard input."""
        if parcel_layer_name != "ΓΕΩΤΕΜΑΧΙΟ":
            return (
                "ΕΠΙΔΙΚΟ_ΤΜΗΜΑ_{}".format(parcel_layer_name),
                "ΓΕΩΤΕΜΑΧΙΟ_ΜΟΡΦΕΣ_ΔΧ_{}".format(parcel_layer_name),
            )
        return "ΕΠΙΔΙΚΟ_ΤΜΗΜΑ", "ΓΕΩΤΕΜΑΧΙΟ_ΜΟΡΦΕΣ_ΔΧ"

    @staticmethod
    def write_csv(path, header, rows):
        with open(path, "w", newline="", encoding="utf-8-sig") as handle:
            writer = csv.writer(handle, delimiter=";")
            writer.writerow(header)
            writer.writerows(rows)

    # ------------------------------------------------------------------ #
    # main
    # ------------------------------------------------------------------ #

    def processAlgorithm(self, parameters, context, feedback):
        StylePostProcessor.instances = []

        parcels = self.parameterAsVectorLayer(parameters, self.PARCELS, context)
        if parcels is None:
            raise QgsProcessingException(self.invalidSourceError(parameters, self.PARCELS))

        forest = self.parameterAsSource(parameters, self.FOREST, context)
        if forest is None:
            raise QgsProcessingException(self.invalidSourceError(parameters, self.FOREST))

        selected_fields = self.parameterAsEnumStrings(parameters, self.FIELDS, context)
        epidiko_values = self.parameterAsEnumStrings(parameters, self.EPIDIKO_VALUES, context)
        target_crs = self.parameterAsCrs(parameters, self.TARGET_CRS, context)
        csv_folder = self.parameterAsString(parameters, self.CSV_FOLDER, context)
        final_columns_raw = self.parameterAsString(parameters, self.FINAL_COLUMNS, context)

        if not selected_fields:
            raise QgsProcessingException(
                self.tr("Select at least one forest cover field to summarise.")
            )
        if not epidiko_values:
            raise QgsProcessingException(
                self.tr("Select at least one KATHGORDX value for the ΕΠΙΔΙΚΟ ΤΜΗΜΑ.")
            )
        feedback.pushInfo("Field validation passed: {}".format(", ".join(selected_fields)))

        if not target_crs.isValid():
            raise QgsProcessingException(self.tr("The chosen coordinate system is not valid."))
        if not crs_is_metric(target_crs):
            feedback.pushWarning(
                "The chosen CRS is not metric - the summarised areas will not be "
                "in square metres."
            )

        forest_fields = forest.fields()
        missing = [f for f in selected_fields if forest_fields.indexOf(f) < 0]
        if forest_fields.indexOf("KATHGORDX") < 0:
            missing.append("KATHGORDX")
        if missing:
            raise QgsProcessingException(
                self.tr("The forest cover layer has no field(s): {}").format(", ".join(missing))
            )

        provider = parcels.dataProvider()
        capabilities = provider.capabilities()
        if not (capabilities & QgsVectorDataProvider.AddAttributes
                and capabilities & QgsVectorDataProvider.ChangeAttributeValues):
            raise QgsProcessingException(
                self.tr(
                    "The parcel layer cannot be edited ({}). This tool writes the "
                    "summary back onto it."
                ).format(parcels.dataProvider().name())
            )

        os.makedirs(csv_folder, exist_ok=True)

        parcel_transform = self.make_transform(parcels.crs(), target_crs, context)
        forest_transform = self.make_transform(forest.sourceCrs(), target_crs, context)

        # -------------------------------------------------------------- #
        # 1. parcel geometries and their own areas
        # -------------------------------------------------------------- #
        feedback.pushInfo("Reading parcels...")
        parcel_geoms = {}
        parcel_areas = {}
        for feature in parcels.getFeatures():
            if feedback.isCanceled():
                return {}
            geom = self.transformed(feature.geometry(), parcel_transform)
            if geom is None:
                feedback.pushWarning(
                    "Parcel {} has no usable geometry - skipped.".format(feature.id())
                )
                continue
            parcel_geoms[feature.id()] = geom
            parcel_areas[feature.id()] = geom.area()

        if not parcel_geoms:
            raise QgsProcessingException(self.tr("The parcel layer has no usable geometries."))
        feedback.pushInfo("{} parcel(s) loaded.".format(len(parcel_geoms)))

        # -------------------------------------------------------------- #
        # 2. cache the forest features that can possibly matter
        # -------------------------------------------------------------- #
        search_rect = QgsRectangle()
        for geom in parcel_geoms.values():
            search_rect.combineExtentWith(geom.boundingBox())

        request_rect = QgsRectangle(search_rect)
        if forest_transform is not None:
            request_rect = forest_transform.transformBoundingBox(
                search_rect, Qgis.TransformDirection.Reverse
            )

        feedback.pushInfo("Reading forest cover in the parcels' extent...")
        request = QgsFeatureRequest().setFilterRect(request_rect)
        forest_cache = {}
        index = QgsSpatialIndex()
        for feature in forest.getFeatures(request):
            if feedback.isCanceled():
                return {}
            geom = self.transformed(feature.geometry(), forest_transform)
            if geom is None:
                continue
            cached = QgsFeature(feature)
            cached.setGeometry(geom)
            forest_cache[feature.id()] = cached
            index.addFeature(cached)

        feedback.pushInfo("{} forest polygon(s) in range.".format(len(forest_cache)))

        # -------------------------------------------------------------- #
        # 3. summarize within: area per (field, category) per parcel
        # -------------------------------------------------------------- #
        feedback.pushInfo("Starting summarization process...")
        # {field: {parcel_fid: {category: area}}}
        summary = {field: {} for field in selected_fields}
        categories = {field: set() for field in selected_fields}

        total = len(parcel_geoms)
        for position, (parcel_fid, parcel_geom) in enumerate(parcel_geoms.items()):
            if feedback.isCanceled():
                return {}
            feedback.setProgress(int(position * 60.0 / total))

            engine = QgsGeometry.createGeometryEngine(parcel_geom.constGet())
            engine.prepareGeometry()

            for candidate_id in index.intersects(parcel_geom.boundingBox()):
                forest_feature = forest_cache[candidate_id]
                forest_geom = forest_feature.geometry()
                if not engine.intersects(forest_geom.constGet()):
                    continue

                piece = polygonal_intersection(parcel_geom, forest_geom)
                if piece is None:
                    continue
                area = piece.area()

                for field in selected_fields:
                    key = self.value_key(field, forest_feature[field])
                    if key is None:
                        continue
                    bucket = summary[field].setdefault(parcel_fid, {})
                    bucket[key] = bucket.get(key, 0.0) + area
                    categories[field].add(key)

        for field in selected_fields:
            feedback.pushInfo(
                "Summarization for field '{}' completed: {} categor{} found.".format(
                    field,
                    len(categories[field]),
                    "y" if len(categories[field]) == 1 else "ies",
                )
            )
            if not categories[field]:
                feedback.pushWarning("No summary data found for field {}.".format(field))

        # -------------------------------------------------------------- #
        # 4. write the summary back onto the parcel layer
        # -------------------------------------------------------------- #
        feedback.pushInfo("Joining summary table with original parcels...")
        max_length = 10 if (parcels.storageType() or "").lower().startswith("esri shape") else 60

        existing_names = [f.name() for f in parcels.fields()]
        new_fields = []

        area_field_name = AREA_FIELD
        if parcels.fields().indexOf(AREA_FIELD) < 0:
            area_field_name = self.sanitise_field_name(AREA_FIELD, existing_names, max_length)
            new_fields.append(QgsField(area_field_name, QVariant.Double, "double", 20, 3))
            existing_names.append(area_field_name)

        # {(field, category): parcel field name}
        column_names = {}
        for field in selected_fields:
            for category in sorted(categories[field]):
                column = self.sanitise_field_name(category, existing_names, max_length)
                column_names[(field, category)] = column
                existing_names.append(column)
                if parcels.fields().indexOf(column) < 0:
                    new_fields.append(QgsField(column, QVariant.Double, "double", 20, 3))

        if new_fields:
            if not provider.addAttributes(new_fields):
                raise QgsProcessingException(
                    self.tr("Could not add the summary fields to the parcel layer.")
                )
            parcels.updateFields()
            feedback.pushInfo(
                "Added {} field(s) to '{}'.".format(len(new_fields), parcels.name())
            )

        field_index = {name: parcels.fields().indexOf(name) for name in existing_names}
        changes = {}
        for parcel_fid in parcel_geoms:
            attributes = {field_index[area_field_name]: round(parcel_areas[parcel_fid], 3)}
            for (field, category), column in column_names.items():
                value = summary[field].get(parcel_fid, {}).get(category, 0.0)
                attributes[field_index[column]] = round(value, 3)
            changes[parcel_fid] = attributes

        if not provider.changeAttributeValues(changes):
            raise QgsProcessingException(
                self.tr("Could not write the summary values onto the parcel layer.")
            )
        parcels.reload()
        parcels.triggerRepaint()
        feedback.setProgress(65)

        # -------------------------------------------------------------- #
        # 5. CSV exports
        # -------------------------------------------------------------- #
        ordered_columns = [column_names[(f, c)]
                           for f in selected_fields
                           for c in sorted(categories[f])]

        draft_path = os.path.join(csv_folder, "Polygon Summary draft.csv")
        draft_rows = [
            [parcel_fid] + [
                round(summary[f].get(parcel_fid, {}).get(c, 0.0), 3)
                for f in selected_fields
                for c in sorted(categories[f])
            ]
            for parcel_fid in sorted(parcel_geoms)
        ]
        self.write_csv(draft_path, ["Join_ID"] + ordered_columns, draft_rows)
        feedback.pushInfo("Summary draft table exported to: {}".format(draft_path))

        if final_columns_raw and final_columns_raw.strip():
            wanted = [c.strip() for c in final_columns_raw.split(";") if c.strip()]
            final_columns = [c for c in wanted if c in ordered_columns]
            for missing_column in [c for c in wanted if c not in ordered_columns]:
                feedback.pushWarning(
                    "Final CSV: column '{}' does not exist - skipped.".format(missing_column)
                )
        else:
            final_columns = ordered_columns

        final_path = os.path.join(csv_folder, "Polygon Summary final.csv")
        final_lookup = {column_names[(f, c)]: (f, c)
                        for f in selected_fields
                        for c in sorted(categories[f])}
        final_rows = []
        for parcel_fid in sorted(parcel_geoms):
            row = [parcel_fid, round(parcel_areas[parcel_fid], 3)]
            for column in final_columns:
                field, category = final_lookup[column]
                row.append(round(summary[field].get(parcel_fid, {}).get(category, 0.0), 3))
            final_rows.append(row)
        self.write_csv(final_path, ["ID", area_field_name] + final_columns, final_rows)
        feedback.pushInfo("Summary table exported to: {}".format(final_path))

        # -------------------------------------------------------------- #
        # 6. ΕΠΙΔΙΚΟ ΤΜΗΜΑ
        # -------------------------------------------------------------- #
        feedback.pushInfo("Computing Epidiko Tmima...")
        epidiko_name, clipped_name = self.build_output_names(parcels.name())
        feedback.pushInfo(
            "Layer name {}ΓΕΩΤΕΜΑΧΙΟ -> using {} names".format(
                "is " if parcels.name() == "ΓΕΩΤΕΜΑΧΙΟ" else "not ",
                "standard" if parcels.name() == "ΓΕΩΤΕΜΑΧΙΟ" else "custom",
            )
        )

        parcel_fid_field = "FID_{}".format(parcels.name())
        epidiko_fields = QgsFields()
        epidiko_fields.append(QgsField(
            self.sanitise_field_name(parcel_fid_field, [], max_length),
            QVariant.LongLong,
        ))
        for name in EPIDIKO_KEEP_FIELDS:
            source_index = forest_fields.indexOf(name)
            if source_index >= 0:
                epidiko_fields.append(forest_fields.at(source_index))
            else:
                feedback.pushWarning(
                    "ΕΠΙΔΙΚΟ ΤΜΗΜΑ: forest layer has no '{}' field - omitted.".format(name)
                )

        epidiko_sink, epidiko_id = self.parameterAsSink(
            parameters, self.EPIDIKO_OUTPUT, context,
            epidiko_fields, QgsWkbTypes.MultiPolygon, target_crs,
        )
        if epidiko_sink is None:
            raise QgsProcessingException(self.invalidSinkError(parameters, self.EPIDIKO_OUTPUT))

        epidiko_set = set(epidiko_values)
        epidiko_count = 0
        for position, (parcel_fid, parcel_geom) in enumerate(parcel_geoms.items()):
            if feedback.isCanceled():
                return {}
            feedback.setProgress(65 + int(position * 15.0 / total))

            engine = QgsGeometry.createGeometryEngine(parcel_geom.constGet())
            engine.prepareGeometry()

            for candidate_id in index.intersects(parcel_geom.boundingBox()):
                forest_feature = forest_cache[candidate_id]
                if str(forest_feature["KATHGORDX"] or "").strip() not in epidiko_set:
                    continue
                forest_geom = forest_feature.geometry()
                if not engine.intersects(forest_geom.constGet()):
                    continue

                piece = polygonal_intersection(parcel_geom, forest_geom)
                if piece is None:
                    continue
                piece.convertToMultiType()

                out_feature = QgsFeature(epidiko_fields)
                out_feature.setGeometry(piece)
                values = [parcel_fid]
                for epidiko_field in list(epidiko_fields)[1:]:
                    values.append(forest_feature[epidiko_field.name()])
                out_feature.setAttributes(values)
                epidiko_sink.addFeature(out_feature, QgsFeatureSink.FastInsert)
                epidiko_count += 1

        feedback.pushInfo(
            "Epidiko Tmima computation completed: {} feature(s).".format(epidiko_count)
        )

        # -------------------------------------------------------------- #
        # 7. ΓΕΩΤΕΜΑΧΙΟ ΜΟΡΦΕΣ ΔΧ (forest cover clipped to the parcels)
        # -------------------------------------------------------------- #
        feedback.pushInfo("Clipping Forest Cover to Cadastral Polygons...")
        clipped_sink, clipped_id = self.parameterAsSink(
            parameters, self.CLIPPED_OUTPUT, context,
            forest_fields, QgsWkbTypes.MultiPolygon, target_crs,
        )
        if clipped_sink is None:
            raise QgsProcessingException(self.invalidSinkError(parameters, self.CLIPPED_OUTPUT))

        parcel_union = QgsGeometry.unaryUnion(list(parcel_geoms.values()))
        if parcel_union.isNull() or parcel_union.isEmpty():
            raise QgsProcessingException(self.tr("Could not dissolve the parcels for clipping."))
        clip_engine = QgsGeometry.createGeometryEngine(parcel_union.constGet())
        clip_engine.prepareGeometry()

        clipped_count = 0
        candidates = list(index.intersects(parcel_union.boundingBox()))
        clip_total = len(candidates) or 1
        for position, candidate_id in enumerate(candidates):
            if feedback.isCanceled():
                return {}
            feedback.setProgress(80 + int(position * 20.0 / clip_total))

            forest_feature = forest_cache[candidate_id]
            forest_geom = forest_feature.geometry()
            if not clip_engine.intersects(forest_geom.constGet()):
                continue

            piece = polygonal_intersection(forest_geom, parcel_union)
            if piece is None:
                continue
            piece.convertToMultiType()

            out_feature = QgsFeature(forest_fields)
            out_feature.setGeometry(piece)
            out_feature.setAttributes(forest_feature.attributes())
            clipped_sink.addFeature(out_feature, QgsFeatureSink.FastInsert)
            clipped_count += 1

        feedback.pushInfo("Clip completed: {} feature(s).".format(clipped_count))

        # -------------------------------------------------------------- #
        # 8. symbology + placement in the layer tree
        # -------------------------------------------------------------- #
        register_style_post_processor(
            context, epidiko_id, "ΕΠΙΔΙΚΟ.qml",
            layer_name=epidiko_name, below_layer_id=parcels.id(),
        )
        register_style_post_processor(
            context, clipped_id, "ΔΑΣΙΚΟΣ.qml",
            layer_name=clipped_name, below_layer_id=parcels.id(),
        )

        feedback.setProgress(100)
        feedback.pushInfo("Finished.")

        return {
            self.EPIDIKO_OUTPUT: epidiko_id,
            self.CLIPPED_OUTPUT: clipped_id,
            self.CSV_FOLDER: csv_folder,
        }

    # ------------------------------------------------------------------ #

    @staticmethod
    def make_transform(source_crs, target_crs, context):
        if source_crs == target_crs:
            return None
        return QgsCoordinateTransform(source_crs, target_crs, context.transformContext())

    @staticmethod
    def transformed(geom, transform):
        if geom is None or geom.isNull() or geom.isEmpty():
            return None
        if transform is None:
            return geom
        clone = QgsGeometry(geom)
        if clone.transform(transform) != 0:
            return None
        return clone
